import { createFileRoute } from "@tanstack/react-router";
import { Workspace } from "@/components/flex/workspace";

export const Route = createFileRoute("/flex")({ component: FlexLine });

function FlexLine() {
  return <Workspace />;
}
