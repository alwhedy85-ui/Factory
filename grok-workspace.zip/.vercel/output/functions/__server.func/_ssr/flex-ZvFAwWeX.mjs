import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ClipboardList, a as Timer, b as Bookmark, c as Smartphone, d as Printer, f as Plus, g as Coins, h as Copy, i as Trash2, l as Shield, n as Warehouse, o as Table2, p as Layers, r as TriangleAlert, s as Spline, t as X, u as RotateCcw, v as CircleCheck, x as ArrowRight, y as Boxes } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/flex-ZvFAwWeX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SCH40 = [
	{
		nps: "1/8",
		od: 10.3,
		wall: 1.73,
		actualId: null,
		coverNps: null
	},
	{
		nps: "1/4",
		od: 13.7,
		wall: 2.24,
		actualId: null,
		coverNps: null
	},
	{
		nps: "3/8",
		od: 17.1,
		wall: 2.31,
		actualId: null,
		coverNps: null
	},
	{
		nps: "1/2",
		od: 21.3,
		wall: 2.77,
		actualId: null,
		coverNps: null
	},
	{
		nps: "3/4",
		od: 26.7,
		wall: 2.87,
		actualId: null,
		coverNps: null
	},
	{
		nps: "1",
		od: 33.4,
		wall: 3.38,
		actualId: null,
		coverNps: null
	},
	{
		nps: "1 1/4",
		od: 42.2,
		wall: 3.56,
		actualId: null,
		coverNps: null
	},
	{
		nps: "1 1/2",
		od: 48.3,
		wall: 3.68,
		actualId: null,
		coverNps: null
	},
	{
		nps: "2",
		od: 60.3,
		wall: 3.91,
		actualId: null,
		coverNps: null
	},
	{
		nps: "2 1/2",
		od: 73,
		wall: 5.16,
		actualId: null,
		coverNps: null
	},
	{
		nps: "3",
		od: 88.9,
		wall: 5.49,
		actualId: null,
		coverNps: null
	},
	{
		nps: "3 1/2",
		od: 101.6,
		wall: 5.74,
		actualId: null,
		coverNps: null
	},
	{
		nps: "4",
		od: 114.3,
		wall: 6.02,
		actualId: 102,
		coverNps: "6"
	},
	{
		nps: "5",
		od: 141.3,
		wall: 6.55,
		actualId: 127,
		coverNps: null
	},
	{
		nps: "6",
		od: 168.3,
		wall: 7.11,
		actualId: 153,
		coverNps: "8"
	},
	{
		nps: "8",
		od: 219.1,
		wall: 8.18,
		actualId: 203,
		coverNps: "10"
	},
	{
		nps: "10",
		od: 273.1,
		wall: 9.27,
		actualId: 255,
		coverNps: "12"
	},
	{
		nps: "12",
		od: 323.9,
		wall: 10.31,
		actualId: 305,
		coverNps: "14"
	},
	{
		nps: "14",
		od: 355.6,
		wall: 11.13,
		actualId: 356,
		coverNps: "16"
	},
	{
		nps: "16",
		od: 406.4,
		wall: 12.7,
		actualId: 406,
		coverNps: "18"
	},
	{
		nps: "18",
		od: 457,
		wall: 14.27,
		actualId: 457,
		coverNps: null
	},
	{
		nps: "20",
		od: 508,
		wall: 15.09,
		actualId: null,
		coverNps: null
	},
	{
		nps: "22",
		od: 559,
		wall: 15.88,
		actualId: null,
		coverNps: null
	},
	{
		nps: "24",
		od: 610,
		wall: 17.48,
		actualId: null,
		coverNps: null
	}
];
var WIRES = [
	{
		key: "0.8",
		mm: .8,
		label: "سلك 0.8 مم",
		gPerM: 4
	},
	{
		key: "0.9",
		mm: .9,
		label: "سلك 0.9 مم",
		gPerM: null
	},
	{
		key: "1",
		mm: 1,
		label: "سلك 1 مم",
		gPerM: 6.11
	},
	{
		key: "1.2",
		mm: 1.2,
		label: "سلك 1.2 مم",
		gPerM: null
	},
	{
		key: "1.4",
		mm: 1.4,
		label: "سلك 1.4 مم",
		gPerM: null
	}
];
var MATERIALS = [
	{
		id: "al-single",
		name: "Aluminum Single (0.012)",
		gPerM: 1.76
	},
	{
		id: "al-double",
		name: "Aluminum Double (0.015)",
		gPerM: 2.89
	},
	{
		id: "pvc",
		name: "PVC",
		gPerM: 5.8
	},
	{
		id: "mpet",
		name: "MPET",
		gPerM: .85
	},
	{
		id: "pure-mpet",
		name: "Clear PET Film",
		gPerM: .87
	}
];
var GLUE_NAME = "الغراء (Water base acrylic)";
function defaultJoint() {
	return {
		lengthM: "1",
		nps: "4",
		layerType: "single",
		wireKey: "0.8",
		pitchMm: "35",
		stripWidthMm: "50",
		material1: "al-double",
		material2: "pvc",
		glueGPerM: "0.22",
		glueRefOverlapMm: "15"
	};
}
function defaultCover() {
	return {
		lengthM: "1",
		nps: "6",
		material: "pvc",
		overlapMm: "15"
	};
}
function defaultInsulated() {
	return {
		lengthM: "1",
		nps: "6"
	};
}
function defaultWool() {
	return {
		thicknessMm: "25",
		density: "16"
	};
}
function defaultSch() {
	return SCH40.map((row) => ({
		nps: row.nps,
		actualId: row.actualId == null ? "" : String(row.actualId),
		coverNps: row.coverNps ?? ""
	}));
}
function defaultWireG() {
	const out = {};
	for (const wire of WIRES) out[wire.key] = wire.gPerM == null ? "" : String(wire.gPerM);
	return out;
}
function defaultMatG() {
	const out = {};
	for (const mat of MATERIALS) out[mat.id] = String(mat.gPerM);
	return out;
}
function priceKeyWire(key) {
	return `wire:${key}`;
}
function priceKeyMat(id) {
	return `mat:${id}`;
}
var PRICE_GLUE = "glue";
var PRICE_WOOL = "wool";
/** Prices written on sheet v15. Empty means the user still has to enter them. */
var SHEET_PRICES = {
	[priceKeyWire("0.8")]: {
		price: "69.81",
		unit: "kg"
	},
	[priceKeyWire("0.9")]: {
		price: "",
		unit: "kg"
	},
	[priceKeyWire("1")]: {
		price: "66.81",
		unit: "kg"
	},
	[priceKeyWire("1.2")]: {
		price: "",
		unit: "kg"
	},
	[priceKeyWire("1.4")]: {
		price: "",
		unit: "kg"
	},
	[priceKeyMat("al-single")]: {
		price: "291.28",
		unit: "kg"
	},
	[priceKeyMat("al-double")]: {
		price: "309.83",
		unit: "kg"
	},
	[priceKeyMat("pvc")]: {
		price: "165.33",
		unit: "kg"
	},
	[priceKeyMat("mpet")]: {
		price: "188.08",
		unit: "kg"
	},
	[priceKeyMat("pure-mpet")]: {
		price: "177.9",
		unit: "kg"
	},
	[PRICE_GLUE]: {
		price: "198.68",
		unit: "kg"
	},
	[PRICE_WOOL]: {
		price: "",
		unit: "kg"
	}
};
function defaultPrices() {
	const out = {};
	for (const wire of WIRES) out[priceKeyWire(wire.key)] = { ...SHEET_PRICES[priceKeyWire(wire.key)] ?? {
		price: "",
		unit: "kg"
	} };
	for (const mat of MATERIALS) out[priceKeyMat(mat.id)] = { ...SHEET_PRICES[priceKeyMat(mat.id)] ?? {
		price: "",
		unit: "kg"
	} };
	out[PRICE_GLUE] = { ...SHEET_PRICES[PRICE_GLUE] };
	out[PRICE_WOOL] = { ...SHEET_PRICES[PRICE_WOOL] };
	return out;
}
function defaultExtras() {
	return [
		{
			id: "waste",
			label: "هالك وفاقد الخامات",
			value: "",
			basis: "pct"
		},
		{
			id: "labor",
			label: "عمالة التشغيل",
			value: "",
			basis: "per_m"
		},
		{
			id: "power",
			label: "كهرباء وطاقة",
			value: "",
			basis: "per_m"
		},
		{
			id: "pack",
			label: "تغليف",
			value: "",
			basis: "per_piece"
		},
		{
			id: "depr",
			label: "إهلاك الماكينات والصيانة",
			value: "",
			basis: "per_m"
		},
		{
			id: "ship",
			label: "نقل وتحميل",
			value: "",
			basis: "per_piece"
		},
		{
			id: "overhead",
			label: "مصروفات عامة وإدارية",
			value: "",
			basis: "pct"
		},
		{
			id: "other",
			label: "تكاليف أخرى",
			value: "",
			basis: "per_piece"
		}
	];
}
function num(raw) {
	if (raw == null) return null;
	const trimmed = raw.trim().replaceAll("٬", "").replace(",", ".");
	if (trimmed === "" || trimmed === "." || trimmed === "-" || trimmed === "-.") return null;
	const value = Number(trimmed);
	return Number.isFinite(value) ? value : null;
}
function schByNps(nps) {
	return SCH40.find((row) => row.nps === nps);
}
function geometricId(row) {
	const raw = row.od - 2 * row.wall;
	return Math.round(raw * 100) / 100;
}
/** Approved ID: manufacturing ID when entered, otherwise OD − 2×wall. */
function approvedId(nps, actualRaw) {
	const spec = schByNps(nps);
	if (!spec) return null;
	const actual = num(actualRaw ?? "");
	if (actual != null && actual > 0) return actual;
	return geometricId(spec);
}
function wireByKey(key) {
	return WIRES.find((wire) => wire.key === key);
}
function materialById(id) {
	return MATERIALS.find((mat) => mat.id === id);
}
/** Scale a measured g/m by diameter squared (steel wire). */
function estimateWireGPerM(mm, refMm, refG) {
	return refG * (mm / refMm) ** 2;
}
function fmt(value, max = 3, min = 0) {
	if (value == null || !Number.isFinite(value)) return "—";
	return new Intl.NumberFormat("en-US", {
		maximumFractionDigits: max,
		minimumFractionDigits: min,
		useGrouping: true
	}).format(value);
}
function defaultTime() {
	return {
		mode: "drive",
		motorRpm: "1400",
		ratedHz: "50",
		setHz: "50",
		gearRatio: "10",
		pulleyMm: "92",
		grooveMm: "3",
		directRpm: "130",
		extraSec: "0",
		headNps: "4",
		freqRows: [
			"10",
			"15",
			"20",
			"25",
			"30",
			"35",
			"40",
			"45",
			"50"
		]
	};
}
function defaultBom() {
	return {
		product: "joint",
		nps: "4",
		lengthM: "10",
		pieces: "1"
	};
}
function emptyCarton() {
	return {
		lengthMm: "",
		widthMm: "",
		heightMm: "",
		pieces: "1",
		price: ""
	};
}
function cartonKey(product, nps) {
	return `${product}|${nps}`;
}
var CARTON_SIZES = [
	...[
		"4",
		"5",
		"6",
		"8",
		"10",
		"12",
		"14",
		"16",
		"18"
	].map((nps) => ({
		product: "joint",
		nps
	})),
	...[
		"4",
		"5",
		"6",
		"8",
		"10",
		"12",
		"14",
		"16",
		"18"
	].map((nps) => ({
		product: "cover",
		nps
	})),
	...[
		"4",
		"6",
		"8",
		"10",
		"12",
		"14",
		"16"
	].map((nps) => ({
		product: "insulated",
		nps
	}))
];
function productLabel(product) {
	if (product === "joint") return "وصلة";
	if (product === "cover") return "Cover";
	return "وصلة معزولة";
}
/** Packing rule: length and width = outer diameter + 50 mm. Height 400 mm, or 1000 mm when insulated. */
function autoCartonMm(product, diameterMm) {
	return {
		lengthMm: diameterMm + 50,
		widthMm: diameterMm + 50,
		heightMm: product === "insulated" ? 1e3 : 400
	};
}
function defaultPlan() {
	return {
		product: "joint",
		nps: "4",
		lengthM: "10",
		batch: "",
		hoursPerDay: "8",
		rateMode: "machine",
		piecesPerDay: "20"
	};
}
function stockCatalog() {
	const items = WIRES.map((wire) => ({
		id: priceKeyWire(wire.key),
		label: wire.label,
		hint: "سلك",
		units: ["kg", "m"],
		defaultUnit: "kg"
	}));
	for (const mat of MATERIALS) items.push({
		id: priceKeyMat(mat.id),
		label: mat.name,
		hint: "شريط عرض 5 سم",
		units: ["kg", "m"],
		defaultUnit: "kg"
	});
	items.push({
		id: PRICE_GLUE,
		label: "الغراء (Water base acrylic)",
		hint: "يُصرف على منطقة التداخل",
		units: ["kg", "g"],
		defaultUnit: "kg"
	});
	items.push({
		id: PRICE_WOOL,
		label: "الصوف الزجاجي",
		hint: "يُستخدم في الوصلة المعزولة فقط",
		units: ["m2", "kg"],
		defaultUnit: "m2"
	});
	return items;
}
function defaultStockItem(item) {
	return {
		qty: "",
		unit: item.defaultUnit
	};
}
function unitLabel(unit) {
	if (unit === "m") return "متر";
	if (unit === "kg") return "كجم";
	if (unit === "g") return "جم";
	if (unit === "m2") return "م²";
	return "كرتونة";
}
function snapshot(state) {
	return {
		joint: state.joint,
		cover: state.cover,
		insulated: state.insulated,
		wool: state.wool,
		wireG: state.wireG,
		matG: state.matG,
		sch: state.sch,
		prices: state.prices,
		extras: state.extras,
		marginPct: state.marginPct,
		currency: state.currency,
		time: state.time,
		bom: state.bom,
		cartons: state.cartons,
		costFocus: state.costFocus
	};
}
function fresh() {
	return {
		section: null,
		precision: false,
		installDismissed: false,
		joint: defaultJoint(),
		cover: defaultCover(),
		insulated: defaultInsulated(),
		wool: defaultWool(),
		wireG: defaultWireG(),
		matG: defaultMatG(),
		sch: defaultSch(),
		prices: defaultPrices(),
		extras: defaultExtras(),
		marginPct: "",
		currency: "جنيه",
		quotes: [],
		time: defaultTime(),
		bom: defaultBom(),
		cartons: {},
		costFocus: "joint",
		stock: {},
		movements: [],
		plan: defaultPlan()
	};
}
var useFlex = create()(persist((set, get) => ({
	...fresh(),
	setSection: (section) => set({ section }),
	setPrecision: (precision) => set({ precision }),
	dismissInstall: () => set({ installDismissed: true }),
	patchJoint: (patch) => set({ joint: {
		...get().joint,
		...patch
	} }),
	patchCover: (patch) => set({ cover: {
		...get().cover,
		...patch
	} }),
	patchInsulated: (patch) => set({ insulated: {
		...get().insulated,
		...patch
	} }),
	patchWool: (patch) => set({ wool: {
		...get().wool,
		...patch
	} }),
	setWireG: (key, value) => set({ wireG: {
		...get().wireG,
		[key]: value
	} }),
	setMatG: (id, value) => set({ matG: {
		...get().matG,
		[id]: value
	} }),
	setSchField: (nps, field, value) => set({ sch: get().sch.map((row) => row.nps === nps ? {
		...row,
		[field]: value
	} : row) }),
	setPrice: (key, patch) => set({ prices: {
		...get().prices,
		[key]: {
			...get().prices[key] ?? {
				price: "",
				unit: "kg"
			},
			...patch
		}
	} }),
	setExtra: (id, patch) => set({ extras: get().extras.map((row) => row.id === id ? {
		...row,
		...patch
	} : row) }),
	addExtra: () => set({ extras: [...get().extras, {
		id: crypto.randomUUID(),
		label: "بند جديد",
		value: "",
		basis: "per_piece"
	}] }),
	removeExtra: (id) => set({ extras: get().extras.filter((row) => row.id !== id) }),
	setMargin: (marginPct) => set({ marginPct }),
	setCurrency: (currency) => set({ currency }),
	restoreSheetPrices: () => set({ prices: defaultPrices() }),
	clearPrices: () => set({
		prices: Object.fromEntries(Object.entries(defaultPrices()).map(([key, value]) => [key, {
			...value,
			price: ""
		}])),
		marginPct: "",
		extras: defaultExtras()
	}),
	estimateWires: () => {
		const wireG = { ...get().wireG };
		const ref = num(wireG["1"]) != null && (num(wireG["1"]) ?? 0) > 0 && {
			mm: 1,
			g: num(wireG["1"])
		} || num(wireG["0.8"]) != null && (num(wireG["0.8"]) ?? 0) > 0 && {
			mm: .8,
			g: num(wireG["0.8"])
		} || null;
		if (!ref) return;
		for (const wire of WIRES) if (num(wireG[wire.key]) == null) wireG[wire.key] = estimateWireGPerM(wire.mm, ref.mm, ref.g).toFixed(2);
		set({ wireG });
	},
	resetRecipe: () => set({
		joint: defaultJoint(),
		cover: defaultCover(),
		insulated: defaultInsulated(),
		wool: defaultWool()
	}),
	resetTables: () => set({
		sch: defaultSch(),
		wireG: defaultWireG(),
		matG: defaultMatG(),
		wool: defaultWool(),
		joint: {
			...get().joint,
			glueGPerM: defaultJoint().glueGPerM,
			glueRefOverlapMm: defaultJoint().glueRefOverlapMm,
			stripWidthMm: defaultJoint().stripWidthMm
		}
	}),
	saveQuote: (name) => {
		const state = get();
		set({ quotes: [{
			id: crypto.randomUUID(),
			name: name.trim() || "حسبة بدون اسم",
			savedAt: (/* @__PURE__ */ new Date()).toISOString(),
			...snapshot(state)
		}, ...state.quotes].slice(0, 24) });
	},
	loadQuote: (id) => {
		const quote = get().quotes.find((item) => item.id === id);
		if (!quote) return;
		set({
			joint: quote.joint,
			cover: quote.cover,
			insulated: quote.insulated,
			wool: quote.wool,
			wireG: quote.wireG,
			matG: quote.matG,
			sch: quote.sch,
			prices: {
				...defaultPrices(),
				...quote.prices
			},
			extras: quote.extras,
			marginPct: quote.marginPct,
			currency: quote.currency,
			time: {
				...defaultTime(),
				...quote.time
			},
			bom: {
				...defaultBom(),
				...quote.bom
			},
			cartons: quote.cartons ?? {},
			costFocus: quote.costFocus ?? "joint"
		});
	},
	deleteQuote: (id) => set({ quotes: get().quotes.filter((item) => item.id !== id) }),
	patchTime: (patch) => set({ time: {
		...get().time,
		...patch
	} }),
	setFreq: (index, value) => {
		const freqRows = [...get().time.freqRows];
		freqRows[index] = value;
		set({ time: {
			...get().time,
			freqRows
		} });
	},
	patchBom: (patch) => set({ bom: {
		...get().bom,
		...patch
	} }),
	patchCarton: (key, patch) => {
		const current = get().cartons[key] ?? emptyCarton();
		set({ cartons: {
			...get().cartons,
			[key]: {
				...current,
				...patch
			}
		} });
	},
	setCostFocus: (costFocus) => set({ costFocus }),
	setStock: (itemId, patch) => {
		const catalog = stockCatalog().find((item) => item.id === itemId);
		const current = get().stock[itemId] ?? (catalog ? defaultStockItem(catalog) : {
			qty: "",
			unit: "kg"
		});
		set({ stock: {
			...get().stock,
			[itemId]: {
				...current,
				...patch
			}
		} });
	},
	postMovement: (itemId, kind, qtyRaw, note) => {
		const qty = num(qtyRaw);
		if (qty == null || qty <= 0) return false;
		const catalog = stockCatalog().find((item) => item.id === itemId);
		const carton = itemId.startsWith("carton:");
		const current = get().stock[itemId] ?? (catalog ? defaultStockItem(catalog) : carton ? {
			qty: "",
			unit: "carton"
		} : {
			qty: "",
			unit: "kg"
		});
		const onHand = num(current.qty) ?? 0;
		const next = kind === "issue" ? onHand - qty : onHand + qty;
		const movement = {
			id: crypto.randomUUID(),
			at: (/* @__PURE__ */ new Date()).toISOString(),
			itemId,
			kind,
			qty: String(qty),
			note: note.trim()
		};
		set({
			stock: {
				...get().stock,
				[itemId]: {
					...current,
					qty: String(Math.round(next * 1e3) / 1e3)
				}
			},
			movements: [movement, ...get().movements].slice(0, 80)
		});
		return true;
	},
	patchPlan: (patch) => set({ plan: {
		...get().plan,
		...patch
	} })
}), {
	name: "flexduct-calc-v2",
	skipHydration: true,
	version: 2,
	merge: (persisted, current) => {
		const saved = persisted ?? {};
		return {
			...current,
			...saved,
			prices: {
				...defaultPrices(),
				...saved.prices ?? {}
			},
			wireG: {
				...defaultWireG(),
				...saved.wireG ?? {}
			},
			matG: {
				...defaultMatG(),
				...saved.matG ?? {}
			},
			time: {
				...defaultTime(),
				...saved.time ?? {}
			},
			bom: {
				...defaultBom(),
				...saved.bom ?? {}
			},
			plan: {
				...defaultPlan(),
				...saved.plan ?? {}
			},
			cartons: saved.cartons ?? {},
			stock: saved.stock ?? {},
			movements: saved.movements ?? [],
			costFocus: saved.costFocus ?? "joint",
			section: saved.section ?? null,
			extras: saved.extras?.length ? saved.extras : defaultExtras(),
			sch: saved.sch?.length ? saved.sch : defaultSch()
		};
	}
}));
function toScenario(state) {
	const schActual = {};
	const schCover = {};
	for (const row of state.sch) {
		schActual[row.nps] = num(row.actualId);
		schCover[row.nps] = row.coverNps.trim();
	}
	const wireG = {};
	for (const [key, value] of Object.entries(state.wireG)) wireG[key] = num(value);
	const matG = {};
	for (const [key, value] of Object.entries(state.matG)) matG[key] = num(value);
	const prices = {};
	for (const [key, value] of Object.entries(state.prices)) prices[key] = {
		price: num(value.price),
		unit: value.unit
	};
	const cartons = {};
	for (const row of CARTON_SIZES) {
		const key = cartonKey(row.product, row.nps);
		const draft = state.cartons[key];
		if (!draft) continue;
		cartons[key] = {
			lengthMm: num(draft.lengthMm),
			widthMm: num(draft.widthMm),
			heightMm: num(draft.heightMm),
			pieces: num(draft.pieces),
			price: num(draft.price)
		};
	}
	return {
		jointLengthM: num(state.joint.lengthM),
		jointNps: state.joint.nps,
		layerType: state.joint.layerType,
		wireKey: state.joint.wireKey,
		pitchMm: num(state.joint.pitchMm),
		stripWidthMm: num(state.joint.stripWidthMm),
		material1: state.joint.material1,
		material2: state.joint.material2,
		glueGPerM: num(state.joint.glueGPerM),
		glueRefOverlapMm: num(state.joint.glueRefOverlapMm),
		coverLengthM: num(state.cover.lengthM),
		coverNps: state.cover.nps,
		coverMaterial: state.cover.material,
		coverOverlapMm: num(state.cover.overlapMm),
		insLengthM: num(state.insulated.lengthM),
		insNps: state.insulated.nps,
		wireG,
		matG,
		schActual,
		schCover,
		woolThkMm: num(state.wool.thicknessMm),
		woolDensity: num(state.wool.density),
		prices,
		extras: state.extras.map((row) => ({
			id: row.id,
			label: row.label,
			value: num(row.value),
			basis: row.basis
		})),
		marginPct: num(state.marginPct),
		costFocus: state.costFocus,
		cartons
	};
}
function toDrive(state) {
	return {
		mode: state.time.mode,
		motorRpm: num(state.time.motorRpm),
		ratedHz: num(state.time.ratedHz),
		setHz: num(state.time.setHz),
		gearRatio: num(state.time.gearRatio),
		pulleyMm: num(state.time.pulleyMm),
		grooveMm: num(state.time.grooveMm),
		directRpm: num(state.time.directRpm),
		extraSec: num(state.time.extraSec),
		freqRows: state.time.freqRows.map((row) => num(row))
	};
}
var bad = (text) => ({
	tone: "bad",
	text
});
var warn = (text) => ({
	tone: "warn",
	text
});
function recipeIssues(scenario) {
	const issues = [];
	const layers = scenario.layerType === "double" ? 2 : 1;
	const overlapMm = scenario.stripWidthMm != null && scenario.pitchMm != null ? scenario.stripWidthMm - scenario.pitchMm : null;
	if (scenario.pitchMm == null || scenario.pitchMm <= 0) issues.push(bad("خطوة السلك لازم تكون أكبر من صفر."));
	if (scenario.stripWidthMm == null || scenario.stripWidthMm <= 0) issues.push(bad("عرض شريط الخامة لازم يكون أكبر من صفر."));
	if (!wireByKey(scenario.wireKey)) issues.push(bad("تخانة السلك غير معرّفة."));
	if (!materialById(scenario.material1)) issues.push(bad("خامة الطبقة الأولى غير معرّفة."));
	if (layers === 2 && !materialById(scenario.material2)) issues.push(bad("خامة الطبقة الثانية غير معرّفة."));
	if (scenario.glueGPerM == null || scenario.glueGPerM < 0) issues.push(bad("كمية الغراء المرجعية ناقصة."));
	if (scenario.glueRefOverlapMm == null || scenario.glueRefOverlapMm <= 0) issues.push(bad("التداخل المرجعي للغراء لازم يكون أكبر من صفر."));
	if (overlapMm != null && overlapMm <= 0) issues.push(warn("التداخل صفر أو سالب — الخطوة أكبر من أو تساوي عرض الشريط."));
	return issues;
}
function helix(lengthM, pitchMm, diameterMm) {
	const turns = lengthM * 1e3 / pitchMm;
	return {
		turns,
		lengthM: turns * Math.hypot(Math.PI * diameterMm, pitchMm) / 1e3
	};
}
function idOf(scenario, nps) {
	return approvedId(nps, scenario.schActual[nps] == null ? "" : String(scenario.schActual[nps]));
}
function weightOfWire(scenario, key) {
	const value = scenario.wireG[key];
	return value == null || value <= 0 ? null : value;
}
function weightOfMat(scenario, id) {
	const value = scenario.matG[id];
	return value == null || value < 0 ? null : value;
}
function glueRate(refG, overlapMm, refOverlapMm) {
	if (!(refOverlapMm > 0) || !Number.isFinite(refG)) return null;
	return refG * overlapMm / refOverlapMm;
}
function calcJoint(scenario, lengthM, nps) {
	const layers = scenario.layerType === "double" ? 2 : 1;
	const idMm = idOf(scenario, nps);
	const overlapMm = scenario.stripWidthMm != null && scenario.pitchMm != null ? scenario.stripWidthMm - scenario.pitchMm : null;
	const issues = [...recipeIssues(scenario)];
	if (lengthM == null || lengthM <= 0) issues.push(bad("طول الوصلة لازم يكون أكبر من صفر."));
	if (!schByNps(nps) || idMm == null || idMm <= 0) issues.push(bad("مقاس NPS غير موجود في جدول Sch 40."));
	const inputOk = !issues.some((issue) => issue.tone === "bad");
	const wire = wireByKey(scenario.wireKey);
	const empty = {
		issues,
		inputOk,
		idMm,
		overlapMm,
		layers,
		turns: null,
		wire: null,
		strip: null,
		totalStripM: null,
		wireGPerM: null,
		mat1GPerM: null,
		mat2GPerM: null,
		wireWeightG: null,
		layer1G: null,
		layer2G: null,
		gluePerM: null,
		glueG: null,
		totalG: null,
		perMeterG: null,
		totalKg: null,
		missingWeights: []
	};
	if (!inputOk || !wire || lengthM == null || scenario.pitchMm == null || idMm == null) return empty;
	const turns = lengthM * 1e3 / scenario.pitchMm;
	const wireHelix = helix(lengthM, scenario.pitchMm, idMm + wire.mm);
	const stripHelix = helix(lengthM, scenario.pitchMm, idMm + 2 * wire.mm);
	const totalStripM = stripHelix.lengthM * layers;
	const wireGPerM = weightOfWire(scenario, wire.key);
	const mat1GPerM = weightOfMat(scenario, scenario.material1);
	const mat2GPerM = layers === 2 ? weightOfMat(scenario, scenario.material2) : 0;
	const missingWeights = [];
	if (wireGPerM == null) missingWeights.push(wire.label);
	if (mat1GPerM == null) missingWeights.push(materialById(scenario.material1)?.name ?? "الطبقة الأولى");
	if (layers === 2 && mat2GPerM == null) missingWeights.push(materialById(scenario.material2)?.name ?? "الطبقة الثانية");
	for (const name of missingWeights) issues.push(warn(`وزن المتر غير مُدخل لـ ${name} في جدول الخامات.`));
	const gluePerM = scenario.glueGPerM != null && scenario.glueRefOverlapMm != null && overlapMm != null ? glueRate(scenario.glueGPerM, overlapMm, scenario.glueRefOverlapMm) : null;
	const wireWeightG = wireGPerM == null ? null : wireHelix.lengthM * wireGPerM;
	const layer1G = mat1GPerM == null ? null : stripHelix.lengthM * mat1GPerM;
	const layer2G = layers === 1 ? 0 : mat2GPerM == null ? null : stripHelix.lengthM * mat2GPerM;
	const glueG = gluePerM == null ? null : gluePerM * stripHelix.lengthM * layers;
	const parts = [
		wireWeightG,
		layer1G,
		layer2G,
		glueG
	];
	const totalG = parts.some((part) => part == null) ? null : parts.reduce((sum, part) => sum + (part ?? 0), 0);
	return {
		issues,
		inputOk: true,
		idMm,
		overlapMm,
		layers,
		turns,
		wire: wireHelix,
		strip: stripHelix,
		totalStripM,
		wireGPerM,
		mat1GPerM,
		mat2GPerM,
		wireWeightG,
		layer1G,
		layer2G,
		gluePerM,
		glueG,
		totalG,
		perMeterG: totalG == null ? null : totalG / lengthM,
		totalKg: totalG == null ? null : totalG / 1e3,
		missingWeights
	};
}
function calcCover(scenario) {
	const issues = [];
	const idMm = idOf(scenario, scenario.coverNps);
	const pitchMm = scenario.stripWidthMm != null && scenario.coverOverlapMm != null ? scenario.stripWidthMm - scenario.coverOverlapMm : null;
	if (scenario.coverLengthM == null || scenario.coverLengthM <= 0) issues.push(bad("طول الـ Cover لازم يكون أكبر من صفر."));
	if (!schByNps(scenario.coverNps) || idMm == null || idMm <= 0) issues.push(bad("مقاس الـ Cover غير موجود في جدول Sch 40."));
	if (!materialById(scenario.coverMaterial)) issues.push(bad("خامة الـ Cover غير معرّفة."));
	if (scenario.coverOverlapMm == null || scenario.coverOverlapMm < 0) issues.push(bad("تداخل الـ Cover ناقص."));
	if (scenario.stripWidthMm == null || scenario.stripWidthMm <= 0) issues.push(bad("عرض الشريط ناقص."));
	if (pitchMm != null && pitchMm <= 0) issues.push(bad("خطوة لفّ الـ Cover لازم تكون أكبر من صفر (عرض الشريط − التداخل)."));
	if (scenario.glueGPerM == null || scenario.glueRefOverlapMm == null || scenario.glueRefOverlapMm <= 0) issues.push(bad("مرجع الغراء ناقص."));
	const inputOk = !issues.some((issue) => issue.tone === "bad");
	const base = {
		issues,
		inputOk,
		idMm,
		pitchMm,
		turns: null,
		stripM: null,
		matGPerM: null,
		matWeightG: null,
		gluePerM: null,
		glueG: null,
		totalG: null,
		perMeterG: null,
		totalKg: null
	};
	if (!inputOk || scenario.coverLengthM == null || pitchMm == null || pitchMm <= 0 || idMm == null) return base;
	const wound = helix(scenario.coverLengthM, pitchMm, idMm);
	const matGPerM = weightOfMat(scenario, scenario.coverMaterial);
	if (matGPerM == null) issues.push(warn("وزن متر خامة الـ Cover غير مُدخل."));
	const gluePerM = scenario.glueGPerM != null && scenario.glueRefOverlapMm != null && scenario.coverOverlapMm != null ? glueRate(scenario.glueGPerM, scenario.coverOverlapMm, scenario.glueRefOverlapMm) : null;
	const matWeightG = matGPerM == null ? null : wound.lengthM * matGPerM;
	const glueG = gluePerM == null ? null : gluePerM * wound.lengthM;
	const totalG = matWeightG == null || glueG == null ? null : matWeightG + glueG;
	return {
		issues,
		inputOk: true,
		idMm,
		pitchMm,
		turns: wound.turns,
		stripM: wound.lengthM,
		matGPerM,
		matWeightG,
		gluePerM,
		glueG,
		totalG,
		perMeterG: totalG == null ? null : totalG / scenario.coverLengthM,
		totalKg: totalG == null ? null : totalG / 1e3
	};
}
function calcInsulated(scenario) {
	const issues = [];
	const idMm = idOf(scenario, scenario.insNps);
	const coverNps = scenario.schCover[scenario.insNps] ?? "";
	const coverIdMm = coverNps ? idOf(scenario, coverNps) : null;
	const wire = wireByKey(scenario.wireKey);
	const recipe = recipeIssues(scenario);
	if (scenario.insLengthM == null || scenario.insLengthM <= 0) issues.push(bad("طول الوصلة المعزولة لازم يكون أكبر من صفر."));
	if (!schByNps(scenario.insNps) || idMm == null) issues.push(bad("مقاس الوصلة المعزولة غير موجود."));
	if (!coverNps) issues.push(bad("مقاس الـ Cover المناسب غير مُدخل في جدول Sch 40 لهذا المقاس."));
	else if (coverIdMm == null) issues.push(bad("مقاس الـ Cover المكتوب في الجدول غير موجود."));
	for (const issue of recipe) if (issue.tone === "bad") issues.push(issue);
	const outerMm = idMm != null && wire ? idMm + 2 * wire.mm : null;
	const insulationMm = outerMm != null && coverIdMm != null ? (coverIdMm - outerMm) / 2 : null;
	if (insulationMm != null && insulationMm <= 0) issues.push(warn("قطر الـ Cover أصغر من أو يساوي القطر الخارجي للوصلة — سمك العزل غير منطقي."));
	const dimsOk = !issues.some((issue) => issue.tone === "bad");
	const pitch = scenario.stripWidthMm != null && scenario.coverOverlapMm != null ? scenario.stripWidthMm - scenario.coverOverlapMm : null;
	if (dimsOk && (pitch == null || pitch <= 0)) issues.push(bad("خطوة لفّ غطاء العزل لازم تكون أكبر من صفر."));
	const ready = dimsOk && pitch != null && pitch > 0;
	const inner = ready ? calcJoint(scenario, scenario.insLengthM, scenario.insNps) : null;
	let woolGPerM2 = null;
	let woolWidthMm = null;
	let woolAreaM2 = null;
	let woolG = null;
	let coverStripM = null;
	let coverMatG = null;
	let coverGluePerM = null;
	let coverGlueG = null;
	let coverTotalG = null;
	if (ready && scenario.insLengthM != null && coverIdMm != null && scenario.woolThkMm != null && scenario.woolThkMm > 0 && scenario.woolDensity != null && scenario.woolDensity > 0) {
		woolGPerM2 = scenario.woolThkMm * scenario.woolDensity;
		woolWidthMm = Math.PI * coverIdMm;
		woolAreaM2 = woolWidthMm / 1e3 * scenario.insLengthM;
		woolG = woolAreaM2 * woolGPerM2;
	} else if (ready) issues.push(bad("سمك أو كثافة الصوف الزجاجي ناقصة."));
	if (ready && scenario.insLengthM != null && coverIdMm != null && pitch != null && pitch > 0) {
		const wound = helix(scenario.insLengthM, pitch, coverIdMm);
		coverStripM = wound.lengthM;
		const gPerM = weightOfMat(scenario, scenario.coverMaterial);
		if (gPerM == null) issues.push(warn("وزن متر خامة الـ Cover غير مُدخل."));
		coverMatG = gPerM == null ? null : wound.lengthM * gPerM;
		coverGluePerM = scenario.glueGPerM != null && scenario.glueRefOverlapMm != null && scenario.coverOverlapMm != null ? glueRate(scenario.glueGPerM, scenario.coverOverlapMm, scenario.glueRefOverlapMm) : null;
		coverGlueG = coverGluePerM == null ? null : coverGluePerM * wound.lengthM;
		coverTotalG = coverMatG == null || coverGlueG == null ? null : coverMatG + coverGlueG;
	}
	const parts = [
		inner?.totalG ?? null,
		woolG,
		coverTotalG
	];
	const totalG = !ready || parts.some((part) => part == null) ? null : parts.reduce((sum, part) => sum + (part ?? 0), 0);
	const lengthM = scenario.insLengthM;
	const finalIssues = [...issues, ...inner?.issues.filter((issue) => issue.tone === "warn") ?? []];
	return {
		issues: finalIssues,
		dimsOk: ready && (inner?.inputOk ?? false) && !finalIssues.some((issue) => issue.tone === "bad"),
		idMm,
		coverNps: coverNps || null,
		coverIdMm,
		outerMm,
		insulationMm,
		inner,
		woolGPerM2,
		woolWidthMm,
		woolAreaM2,
		woolG,
		coverStripM,
		coverMatG,
		coverGluePerM,
		coverGlueG,
		coverTotalG,
		totalG,
		perMeterG: totalG == null || lengthM == null || lengthM <= 0 ? null : totalG / lengthM,
		totalKg: totalG == null ? null : totalG / 1e3
	};
}
function lineCost(qty, price, unit, perBasis, qtyKind) {
	if (qty == null) return {
		unitPrice: null,
		cost: null,
		missing: "الكمية غير مكتملة"
	};
	if (price == null) return {
		unitPrice: null,
		cost: null,
		missing: "السعر غير مُدخل"
	};
	if (qtyKind === "g") {
		const unitPrice = price / 1e3;
		return {
			unitPrice,
			cost: qty * unitPrice,
			missing: null
		};
	}
	if (qtyKind === "m2") {
		if (unit === "m2") return {
			unitPrice: price,
			cost: qty * price,
			missing: null
		};
		if (perBasis == null) return {
			unitPrice: null,
			cost: null,
			missing: "وزن المتر المربع غير مكتمل"
		};
		const unitPrice = price * perBasis / 1e3;
		return {
			unitPrice,
			cost: qty * unitPrice,
			missing: null
		};
	}
	if (unit === "m") return {
		unitPrice: price,
		cost: qty * price,
		missing: null
	};
	if (perBasis == null) return {
		unitPrice: null,
		cost: null,
		missing: "وزن المتر غير مُدخل"
	};
	const unitPrice = price * perBasis / 1e3;
	return {
		unitPrice,
		cost: qty * unitPrice,
		missing: null
	};
}
function pushLine(lines, missing, line) {
	const priced = lineCost(line.qty, line.price, line.priceUnit, line.perBasis, line.qtyKind);
	if (priced.missing && line.qty !== 0) missing.push(`${line.chosen}: ${priced.missing}`);
	lines.push({
		id: line.id,
		label: line.label,
		qty: line.qty,
		unit: line.unit,
		unitPrice: line.qty === 0 ? 0 : priced.unitPrice,
		cost: line.qty === 0 ? 0 : priced.cost,
		chosen: line.chosen,
		missing: line.qty === 0 ? null : priced.missing
	});
}
function sumCosts(lines) {
	if (lines.some((line) => line.cost == null)) return null;
	return lines.reduce((sum, line) => sum + (line.cost ?? 0), 0);
}
function priceOf(scenario, key) {
	return scenario.prices[key] ?? {
		price: null,
		unit: "kg"
	};
}
function calcCost(scenario, joint, cover, insulated) {
	const jointLines = [];
	const jointMissing = [];
	const wire = wireByKey(scenario.wireKey);
	const mat1 = materialById(scenario.material1);
	const mat2 = materialById(scenario.material2);
	const wirePrice = priceOf(scenario, priceKeyWire(scenario.wireKey));
	const mat1Price = priceOf(scenario, priceKeyMat(scenario.material1));
	const mat2Price = priceOf(scenario, priceKeyMat(scenario.material2));
	const gluePrice = priceOf(scenario, PRICE_GLUE);
	pushLine(jointLines, jointMissing, {
		id: "wire",
		label: "السلك",
		qty: joint.wire?.lengthM ?? null,
		unit: "m",
		chosen: wire?.label ?? "السلك",
		price: wirePrice.price,
		priceUnit: wirePrice.unit,
		perBasis: joint.wireGPerM,
		qtyKind: "m"
	});
	pushLine(jointLines, jointMissing, {
		id: "layer1",
		label: "الطبقة الأولى",
		qty: joint.strip?.lengthM ?? null,
		unit: "m",
		chosen: mat1?.name ?? "الطبقة الأولى",
		price: mat1Price.price,
		priceUnit: mat1Price.unit,
		perBasis: joint.mat1GPerM,
		qtyKind: "m"
	});
	pushLine(jointLines, jointMissing, {
		id: "layer2",
		label: "الطبقة الثانية",
		qty: joint.layers === 2 ? joint.strip?.lengthM ?? null : 0,
		unit: "m",
		chosen: joint.layers === 2 ? mat2?.name ?? "الطبقة الثانية" : "— (Single layer)",
		price: mat2Price.price,
		priceUnit: mat2Price.unit,
		perBasis: joint.mat2GPerM,
		qtyKind: "m"
	});
	pushLine(jointLines, jointMissing, {
		id: "glue",
		label: "الغراء",
		qty: joint.glueG,
		unit: "جم",
		chosen: "Water base acrylic (السعر لكل جم)",
		price: gluePrice.price,
		priceUnit: "kg",
		perBasis: null,
		qtyKind: "g"
	});
	const jointMaterial = sumCosts(jointLines);
	const coverLines = [];
	const coverMissing = [];
	const coverMat = materialById(scenario.coverMaterial);
	const coverPrice = priceOf(scenario, priceKeyMat(scenario.coverMaterial));
	pushLine(coverLines, coverMissing, {
		id: "cover-mat",
		label: "الـ Cover المستقل — الخامة",
		qty: cover.stripM,
		unit: "m",
		chosen: coverMat?.name ?? "Cover",
		price: coverPrice.price,
		priceUnit: coverPrice.unit,
		perBasis: cover.matGPerM,
		qtyKind: "m"
	});
	pushLine(coverLines, coverMissing, {
		id: "cover-glue",
		label: "الـ Cover المستقل — الغراء",
		qty: cover.glueG,
		unit: "جم",
		chosen: "Water base acrylic (السعر لكل جم)",
		price: gluePrice.price,
		priceUnit: "kg",
		perBasis: null,
		qtyKind: "g"
	});
	const insLines = [];
	const insMissing = [];
	const woolPrice = priceOf(scenario, PRICE_WOOL);
	const inner = insulated.inner;
	pushLine(insLines, insMissing, {
		id: "wool",
		label: "المعزولة — الصوف الزجاجي",
		qty: insulated.woolAreaM2,
		unit: "م²",
		chosen: "Glass wool",
		price: woolPrice.price,
		priceUnit: woolPrice.unit === "m" ? "kg" : woolPrice.unit,
		perBasis: insulated.woolGPerM2,
		qtyKind: "m2"
	});
	pushLine(insLines, insMissing, {
		id: "ins-cover",
		label: "المعزولة — خامة الـ Cover",
		qty: insulated.coverStripM,
		unit: "m",
		chosen: coverMat?.name ?? "Cover",
		price: coverPrice.price,
		priceUnit: coverPrice.unit,
		perBasis: weightOfMat(scenario, scenario.coverMaterial),
		qtyKind: "m"
	});
	pushLine(insLines, insMissing, {
		id: "ins-cover-glue",
		label: "المعزولة — غراء الـ Cover",
		qty: insulated.coverGlueG,
		unit: "جم",
		chosen: "Water base acrylic (السعر لكل جم)",
		price: gluePrice.price,
		priceUnit: "kg",
		perBasis: null,
		qtyKind: "g"
	});
	pushLine(insLines, insMissing, {
		id: "ins-wire",
		label: "المعزولة — سلك الوصلة الداخلية",
		qty: inner?.wire?.lengthM ?? null,
		unit: "m",
		chosen: wire?.label ?? "السلك",
		price: wirePrice.price,
		priceUnit: wirePrice.unit,
		perBasis: inner?.wireGPerM ?? null,
		qtyKind: "m"
	});
	pushLine(insLines, insMissing, {
		id: "ins-l1",
		label: "المعزولة — الطبقة الأولى",
		qty: inner?.strip?.lengthM ?? null,
		unit: "m",
		chosen: mat1?.name ?? "الطبقة الأولى",
		price: mat1Price.price,
		priceUnit: mat1Price.unit,
		perBasis: inner?.mat1GPerM ?? null,
		qtyKind: "m"
	});
	pushLine(insLines, insMissing, {
		id: "ins-l2",
		label: "المعزولة — الطبقة الثانية",
		qty: inner == null ? null : inner.layers === 2 ? inner.strip?.lengthM ?? null : 0,
		unit: "m",
		chosen: inner != null && inner.layers === 2 ? mat2?.name ?? "الطبقة الثانية" : "— (Single layer)",
		price: mat2Price.price,
		priceUnit: mat2Price.unit,
		perBasis: inner?.mat2GPerM ?? null,
		qtyKind: "m"
	});
	pushLine(insLines, insMissing, {
		id: "ins-glue",
		label: "المعزولة — غراء الوصلة الداخلية",
		qty: inner?.glueG ?? null,
		unit: "جم",
		chosen: "Water base acrylic (السعر لكل جم)",
		price: gluePrice.price,
		priceUnit: "kg",
		perBasis: null,
		qtyKind: "g"
	});
	const insTotal = sumCosts(insLines);
	const coverMaterial = sumCosts(coverLines);
	const focus = scenario.costFocus ?? "joint";
	const focusMaterial = focus === "joint" ? jointMaterial : focus === "cover" ? coverMaterial : insTotal;
	const focusLength = focus === "joint" ? scenario.jointLengthM : focus === "cover" ? scenario.coverLengthM : scenario.insLengthM;
	const carton = quoteCarton(scenario, focus, focus === "joint" ? scenario.jointNps : focus === "cover" ? scenario.coverNps : scenario.insNps, focus === "insulated" ? insulated.coverIdMm : focus === "cover" ? cover.idMm : joint.idMm);
	let extrasSkipped = 0;
	const extras = scenario.extras.map((extra) => {
		const basisText = extra.basis === "pct" ? "% من الخامات" : extra.basis === "per_m" ? "جنيه/متر" : "جنيه/قطعة";
		if (extra.value == null) {
			extrasSkipped += 1;
			return {
				id: extra.id,
				label: extra.label,
				basis: extra.basis,
				basisText,
				base: null,
				cost: 0
			};
		}
		if (extra.basis === "pct") {
			if (focusMaterial == null) return {
				id: extra.id,
				label: extra.label,
				basis: extra.basis,
				basisText,
				base: null,
				cost: null
			};
			return {
				id: extra.id,
				label: extra.label,
				basis: extra.basis,
				basisText,
				base: focusMaterial,
				cost: extra.value / 100 * focusMaterial
			};
		}
		const lengthM = focusLength ?? 0;
		if (extra.basis === "per_m") return {
			id: extra.id,
			label: extra.label,
			basis: extra.basis,
			basisText,
			base: lengthM,
			cost: extra.value * lengthM
		};
		return {
			id: extra.id,
			label: extra.label,
			basis: extra.basis,
			basisText,
			base: 1,
			cost: extra.value
		};
	});
	const extrasTotal = extras.some((extra) => extra.cost == null) ? null : extras.reduce((sum, extra) => sum + (extra.cost ?? 0), 0);
	const cartonSkipped = carton?.missingPrice ?? false;
	const cartonCost = cartonSkipped ? 0 : carton?.costPerPiece ?? 0;
	const total = focusMaterial == null || extrasTotal == null ? null : focusMaterial + extrasTotal + cartonCost;
	const marginPct = scenario.marginPct;
	const profit = total == null || marginPct == null ? null : total * marginPct / 100;
	const sell = total == null || profit == null ? null : total + profit;
	const costPerM = total == null || focusLength == null || focusLength <= 0 ? null : total / focusLength;
	const sellPerM = sell == null || focusLength == null || focusLength <= 0 ? null : sell / focusLength;
	const insLen = scenario.insLengthM;
	return {
		currencyNote: GLUE_NAME,
		jointLines,
		jointMaterial,
		jointMissing,
		extras,
		extrasTotal,
		total,
		marginPct,
		profit,
		sell,
		costPerM,
		sellPerM,
		coverLines,
		coverTotal: coverMaterial,
		coverMissing,
		insLines,
		insTotal,
		insMissing,
		insPerM: insTotal == null || insLen == null || insLen <= 0 ? null : insTotal / insLen,
		focus,
		carton,
		cartonSkipped,
		extrasSkipped
	};
}
function quoteCarton(scenario, product, nps, diameterMm) {
	const meta = scenario.cartons[cartonKey(product, nps)];
	const auto = diameterMm != null && diameterMm > 0 ? autoCartonMm(product, diameterMm) : null;
	const lengthMm = meta?.lengthMm != null && meta.lengthMm > 0 ? meta.lengthMm : auto?.lengthMm ?? null;
	const widthMm = meta?.widthMm != null && meta.widthMm > 0 ? meta.widthMm : auto?.widthMm ?? null;
	const heightMm = meta?.heightMm != null && meta.heightMm > 0 ? meta.heightMm : auto?.heightMm ?? null;
	const manual = Boolean(meta?.lengthMm != null && meta.lengthMm > 0 || meta?.widthMm != null && meta.widthMm > 0 || meta?.heightMm != null && meta.heightMm > 0);
	const piecesPerCarton = meta?.pieces != null && meta.pieces > 0 ? meta.pieces : 1;
	const unitPrice = meta?.price != null && meta.price >= 0 ? meta.price : null;
	const missingPrice = unitPrice == null;
	const costPerPiece = unitPrice == null ? null : unitPrice / piecesPerCarton;
	return {
		key: cartonKey(product, nps),
		product,
		nps,
		diameterMm,
		lengthMm,
		widthMm,
		heightMm,
		auto: !manual,
		piecesPerCarton,
		cartonsForOne: 1 / piecesPerCarton,
		unitPrice,
		costPerPiece,
		missingPrice
	};
}
function hms(totalSec) {
	const rounded = Math.round(totalSec);
	const sign = rounded < 0 ? "-" : "";
	const abs = Math.abs(rounded);
	const hours = Math.floor(abs / 3600);
	const minutes = Math.floor(abs % 3600 / 60);
	const seconds = abs % 60;
	return `${sign}${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
function calcTime(scenario, drive, lengthM, pitchMm, headNps) {
	const issues = [];
	const headIdMm = idOf(scenario, headNps);
	if (lengthM == null || lengthM <= 0) issues.push(bad("طول الوصلة لازم يكون أكبر من صفر."));
	if (pitchMm == null || pitchMm <= 0) issues.push(bad("خطوة اللفة لازم تكون أكبر من صفر."));
	if (headIdMm == null || headIdMm <= 0) issues.push(bad("مقاس الـ Head غير موجود في جدول Sch 40."));
	if (drive.grooveMm == null || drive.grooveMm < 0) issues.push(bad("خصم الفريز ناقص."));
	const headEffMm = headIdMm != null && drive.grooveMm != null ? headIdMm - drive.grooveMm : null;
	if (headEffMm != null && headEffMm <= 0) issues.push(bad("القطر الفعّال للـ Head لازم يكون أكبر من صفر."));
	let motorRpm = null;
	let pulleyRpm = null;
	let beltMPerMin = null;
	let headRpmCalc = null;
	if (drive.mode === "direct") {
		if (drive.directRpm == null || drive.directRpm <= 0) issues.push(bad("دوران الـ Head المُدخل لازم يكون أكبر من صفر."));
	} else {
		if (drive.motorRpm == null || drive.motorRpm <= 0) issues.push(bad("سرعة الماتور لازم تكون أكبر من صفر."));
		if (drive.ratedHz == null || drive.ratedHz <= 0) issues.push(bad("التردد المقنن لازم يكون أكبر من صفر."));
		if (drive.setHz == null || drive.setHz <= 0) issues.push(bad("تردد الانفرتر لازم يكون أكبر من صفر."));
		if (drive.gearRatio == null || drive.gearRatio <= 0) issues.push(bad("نسبة التخفيض لازم تكون أكبر من صفر."));
		if (drive.pulleyMm == null || drive.pulleyMm <= 0) issues.push(bad("قطر الطنبورة لازم يكون أكبر من صفر."));
		if (drive.motorRpm != null && drive.ratedHz != null && drive.ratedHz > 0 && drive.setHz != null && drive.gearRatio != null && drive.gearRatio > 0 && drive.pulleyMm != null && headEffMm != null && headEffMm > 0) {
			motorRpm = drive.motorRpm * (drive.setHz / drive.ratedHz);
			pulleyRpm = motorRpm / drive.gearRatio;
			beltMPerMin = Math.PI * drive.pulleyMm * pulleyRpm / 1e3;
			headRpmCalc = pulleyRpm * drive.pulleyMm / headEffMm;
		}
	}
	const headRpm = drive.mode === "direct" ? drive.directRpm : headRpmCalc;
	const inputOk = !issues.some((issue) => issue.tone === "bad") && headRpm != null && headRpm > 0;
	const turns = lengthM != null && pitchMm != null && pitchMm > 0 ? lengthM * 1e3 / pitchMm : null;
	const extra = drive.extraSec != null && drive.extraSec >= 0 ? drive.extraSec : 0;
	const turnSec = inputOk && headRpm ? 60 / headRpm : null;
	const advanceMPerMin = inputOk && headRpm && pitchMm ? headRpm * pitchMm / 1e3 : null;
	const windSec = inputOk && headRpm && turns != null ? turns / headRpm * 60 : null;
	const totalSec = windSec == null ? null : windSec + extra;
	const rows = drive.freqRows.map((hz) => freqRow(drive, headEffMm, turns, extra, hz));
	return {
		issues,
		inputOk,
		lengthM,
		pitchMm,
		turns,
		headIdMm,
		motorRpm,
		pulleyRpm,
		beltMPerMin,
		headEffMm,
		headRpmCalc,
		headRpm: inputOk ? headRpm : headRpm,
		turnSec,
		advanceMPerMin,
		windSec,
		totalSec,
		totalMin: totalSec == null ? null : totalSec / 60,
		hms: totalSec == null ? null : hms(totalSec),
		perHour: totalSec != null && totalSec > 0 ? 3600 / totalSec : null,
		rows
	};
}
function freqRow(drive, headEffMm, turns, extra, hz) {
	if (hz == null || hz <= 0 || drive.motorRpm == null || drive.ratedHz == null || drive.ratedHz <= 0 || drive.gearRatio == null || drive.gearRatio <= 0 || drive.pulleyMm == null || drive.pulleyMm <= 0 || headEffMm == null || headEffMm <= 0) return {
		hz,
		headRpm: null,
		totalSec: null,
		perHour: null
	};
	const headRpm = drive.motorRpm * (hz / drive.ratedHz) / drive.gearRatio * (drive.pulleyMm / headEffMm);
	if (!(headRpm > 0) || turns == null) return {
		hz,
		headRpm,
		totalSec: null,
		perHour: null
	};
	const totalSec = turns / headRpm * 60 + extra;
	return {
		hz,
		headRpm,
		totalSec,
		perHour: totalSec > 0 ? 3600 / totalSec : null
	};
}
function calcBom(scenario, product, nps, lengthM, pieces) {
	const scoped = {
		...scenario,
		jointLengthM: product === "joint" ? lengthM : scenario.jointLengthM,
		jointNps: product === "joint" ? nps : scenario.jointNps,
		coverLengthM: product === "cover" ? lengthM : scenario.coverLengthM,
		coverNps: product === "cover" ? nps : scenario.coverNps,
		insLengthM: product === "insulated" ? lengthM : scenario.insLengthM,
		insNps: product === "insulated" ? nps : scenario.insNps
	};
	const joint = calcJoint(scoped, scoped.jointLengthM, scoped.jointNps);
	const cover = calcCover(scoped);
	const insulated = calcInsulated(scoped);
	const wire = wireByKey(scenario.wireKey);
	const mat1 = materialById(scenario.material1);
	const mat2 = materialById(scenario.material2);
	const coverMat = materialById(scenario.coverMaterial);
	const issues = [];
	if (lengthM == null || lengthM <= 0) issues.push(bad("طول القطعة لازم يكون أكبر من صفر."));
	if (pieces == null || pieces <= 0) issues.push(bad("عدد القطع لازم يكون أكبر من صفر."));
	if (product === "joint") issues.push(...joint.issues);
	if (product === "cover") issues.push(...cover.issues);
	if (product === "insulated") issues.push(...insulated.issues);
	const scale = (qty) => qty == null || pieces == null ? null : qty * pieces;
	const useJoint = product === "joint" || product === "insulated";
	const useCover = product === "cover" || product === "insulated";
	const useWool = product === "insulated";
	const jointSrc = product === "insulated" ? insulated.inner : joint;
	const layer2Applies = useJoint && (jointSrc?.layers ?? 1) === 2;
	const lines = [
		{
			id: "wire",
			item: "سلك الوصلة",
			spec: wire?.label ?? "سلك",
			qty: useJoint ? jointSrc?.wire?.lengthM ?? null : null,
			unit: "m",
			weightG: useJoint ? jointSrc?.wireWeightG ?? null : null,
			orderQty: useJoint ? scale(jointSrc?.wire?.lengthM ?? null) : null,
			applies: useJoint
		},
		{
			id: "layer1",
			item: "شريط الوصلة — الطبقة الأولى",
			spec: mat1?.name ?? "—",
			qty: useJoint ? jointSrc?.strip?.lengthM ?? null : null,
			unit: "m",
			weightG: useJoint ? jointSrc?.layer1G ?? null : null,
			orderQty: useJoint ? scale(jointSrc?.strip?.lengthM ?? null) : null,
			applies: useJoint
		},
		{
			id: "layer2",
			item: "شريط الوصلة — الطبقة الثانية",
			spec: layer2Applies ? mat2?.name ?? "—" : "—",
			qty: layer2Applies ? jointSrc?.strip?.lengthM ?? null : null,
			unit: "m",
			weightG: layer2Applies ? jointSrc?.layer2G ?? null : null,
			orderQty: layer2Applies ? scale(jointSrc?.strip?.lengthM ?? null) : null,
			applies: layer2Applies
		},
		{
			id: "glue",
			item: "غراء الوصلة",
			spec: "Water base acrylic",
			qty: useJoint ? jointSrc?.glueG ?? null : null,
			unit: "جم",
			weightG: useJoint ? jointSrc?.glueG ?? null : null,
			orderQty: useJoint ? scale(jointSrc?.glueG ?? null) : null,
			applies: useJoint
		},
		{
			id: "wool",
			item: "صوف زجاجي (Glass wool)",
			spec: useWool ? `${insulated.woolGPerM2 ?? "—"} جم/م²` : "—",
			qty: useWool ? insulated.woolAreaM2 ?? null : null,
			unit: "م²",
			weightG: useWool ? insulated.woolG ?? null : null,
			orderQty: useWool ? scale(insulated.woolAreaM2 ?? null) : null,
			applies: useWool
		},
		{
			id: "cover",
			item: "شريط الـ Cover",
			spec: useCover ? coverMat?.name ?? "—" : "—",
			qty: product === "cover" ? cover.stripM : product === "insulated" ? insulated.coverStripM : null,
			unit: "m",
			weightG: product === "cover" ? cover.matWeightG : product === "insulated" ? insulated.coverMatG : null,
			orderQty: product === "cover" ? scale(cover.stripM) : product === "insulated" ? scale(insulated.coverStripM) : null,
			applies: useCover
		},
		{
			id: "cover-glue",
			item: "غراء الـ Cover",
			spec: useCover ? "Water base acrylic" : "—",
			qty: product === "cover" ? cover.glueG : product === "insulated" ? insulated.coverGlueG : null,
			unit: "جم",
			weightG: product === "cover" ? cover.glueG : product === "insulated" ? insulated.coverGlueG : null,
			orderQty: product === "cover" ? scale(cover.glueG) : product === "insulated" ? scale(insulated.coverGlueG) : null,
			applies: useCover
		}
	];
	const carton = quoteCarton(scenario, product, nps, product === "joint" ? joint.idMm : product === "cover" ? cover.idMm : insulated.coverIdMm);
	const cartons = pieces == null ? null : Math.ceil(pieces / carton.piecesPerCarton);
	lines.push({
		id: "carton",
		item: "كرتونة التغليف",
		spec: carton.lengthMm == null ? "القطر غير معروف" : `${Math.round(carton.lengthMm)} × ${Math.round(carton.widthMm ?? 0)} × ${Math.round(carton.heightMm ?? 0)} مم`,
		qty: cartons,
		unit: "كرتونة",
		weightG: null,
		orderQty: cartons,
		applies: true
	});
	const pieceParts = product === "joint" ? [joint.totalG] : product === "cover" ? [cover.totalG] : [insulated.totalG];
	const pieceWeightG = pieceParts.some((part) => part == null) ? null : pieceParts[0] ?? null;
	return {
		issues,
		lines,
		pieceWeightG,
		orderWeightKg: pieceWeightG == null || pieces == null ? null : pieceWeightG * pieces / 1e3,
		carton,
		cartons,
		idMm: product === "insulated" ? insulated.idMm : product === "cover" ? cover.idMm : joint.idMm,
		coverNps: product === "insulated" ? insulated.coverNps : product === "cover" ? nps : null,
		coverIdMm: product === "insulated" ? insulated.coverIdMm : product === "cover" ? cover.idMm : null
	};
}
function addNeed(map, itemId, label, unit, qty) {
	const prev = map.get(itemId);
	if (qty == null || prev != null && prev.perPiece == null) {
		map.set(itemId, {
			itemId,
			label: prev?.label ?? label,
			perPiece: null,
			unit
		});
		return;
	}
	map.set(itemId, {
		itemId,
		label,
		perPiece: (prev?.perPiece ?? 0) + qty,
		unit
	});
}
function bomNeeds(scenario, bom, product) {
	const map = /* @__PURE__ */ new Map();
	const wire = wireByKey(scenario.wireKey);
	const mat1 = materialById(scenario.material1);
	const mat2 = materialById(scenario.material2);
	const coverMat = materialById(scenario.coverMaterial);
	const byId = (id) => bom.lines.find((line) => line.id === id);
	if (product !== "cover" && wire) addNeed(map, priceKeyWire(wire.key), wire.label, "m", byId("wire")?.qty ?? null);
	if (product !== "cover" && mat1) addNeed(map, priceKeyMat(mat1.id), mat1.name, "m", byId("layer1")?.qty ?? null);
	if (product !== "cover" && (byId("layer2")?.applies ?? false) && mat2) addNeed(map, priceKeyMat(mat2.id), mat2.name, "m", byId("layer2")?.qty ?? null);
	if (product !== "cover") addNeed(map, PRICE_GLUE, "الغراء", "g", byId("glue")?.qty ?? null);
	if (product !== "joint" && coverMat) addNeed(map, priceKeyMat(coverMat.id), coverMat.name, "m", byId("cover")?.qty ?? null);
	if (product !== "joint") addNeed(map, PRICE_GLUE, "الغراء", "g", byId("cover-glue")?.qty ?? null);
	if (product === "insulated") addNeed(map, PRICE_WOOL, "الصوف الزجاجي", "m2", byId("wool")?.qty ?? null);
	if (bom.carton) addNeed(map, `carton:${bom.carton.key}`, `كرتونة ${productLabel(product)} ${bom.carton.nps}″`, "carton", bom.carton.cartonsForOne);
	return [...map.values()];
}
function stockToCanonical(itemId, qty, unit, scenario) {
	if (qty == null) return null;
	if (itemId.startsWith("carton:")) return unit === "carton" ? qty : null;
	if (itemId === "glue") {
		if (unit === "g") return qty;
		if (unit === "kg") return qty * 1e3;
		return null;
	}
	if (itemId === "wool") {
		const gsm = scenario.woolThkMm != null && scenario.woolDensity != null ? scenario.woolThkMm * scenario.woolDensity : null;
		if (unit === "m2") return qty;
		if (unit === "kg" && gsm != null && gsm > 0) return qty * 1e3 / gsm;
		return null;
	}
	if (itemId.startsWith("wire:")) {
		const gPerM = scenario.wireG[itemId.slice(5)] ?? null;
		if (unit === "m") return qty;
		if (unit === "kg" && gPerM != null && gPerM > 0) return qty * 1e3 / gPerM;
		return null;
	}
	if (itemId.startsWith("mat:")) {
		const gPerM = scenario.matG[itemId.slice(4)] ?? null;
		if (unit === "m") return qty;
		if (unit === "kg" && gPerM != null && gPerM > 0) return qty * 1e3 / gPerM;
		return null;
	}
	return null;
}
function calcCoverage(needs, stock, secondsPerPiece, hoursPerDay, batch, scenario) {
	const rows = needs.map((need) => {
		const held = stock[need.itemId];
		const onHand = stockToCanonical(need.itemId, held?.qty ?? null, held?.unit ?? "kg", scenario);
		const pieces = need.perPiece != null && need.perPiece > 0 && onHand != null ? onHand / need.perPiece : onHand === 0 ? 0 : null;
		const hours = pieces != null && secondsPerPiece != null && secondsPerPiece > 0 ? pieces * secondsPerPiece / 3600 : null;
		const days = hours != null && hoursPerDay != null && hoursPerDay > 0 ? hours / hoursPerDay : null;
		const batchNeed = need.perPiece != null && batch != null ? need.perPiece * batch : null;
		const batchOk = batchNeed != null && onHand != null ? onHand + 1e-9 >= batchNeed : null;
		let note = null;
		if (held?.qty == null) note = "الرصيد غير مُدخل";
		else if (need.perPiece == null) note = "استهلاك القطعة غير مكتمل";
		else if (onHand == null) note = "وحدة الرصيد لا تتحول لوحدة الاستهلاك";
		return {
			itemId: need.itemId,
			label: need.label,
			perPiece: need.perPiece,
			unit: need.unit,
			stock: onHand,
			pieces,
			hours,
			days,
			batchNeed,
			batchOk,
			note
		};
	});
	const bottleneck = rows.filter((row) => row.pieces != null).reduce((best, row) => {
		if (best == null || (row.pieces ?? Infinity) < (best.pieces ?? Infinity)) return row;
		return best;
	}, null);
	const piecesPerHour = secondsPerPiece != null && secondsPerPiece > 0 ? 3600 / secondsPerPiece : null;
	let headline = "أدخل رصيد الخامات لمعرفة مدة التغطية.";
	if (bottleneck?.pieces != null) {
		const pieceText = formatCount(bottleneck.pieces);
		if (bottleneck.pieces <= 0) headline = `${bottleneck.label} رصيدها لا يكفي لأي قطعة من هذا المقاس.`;
		else if (bottleneck.hours != null && bottleneck.days != null) headline = `أضيق خامة هي ${bottleneck.label}: تكفي ${pieceText} قطعة، أي ${formatHours(bottleneck.hours)} (${formatDays(bottleneck.days)}).`;
		else headline = `${bottleneck.label} تكفي ${pieceText} قطعة. زمن الماكينة غير مكتمل، فالمدة بالساعات غير محسوبة.`;
	}
	return {
		rows,
		secondsPerPiece,
		piecesPerHour,
		bottleneck,
		headline
	};
}
function formatCount(value) {
	if (value < 10) return value.toFixed(1);
	return Math.floor(value).toLocaleString("en-US");
}
function formatHours(hours) {
	if (hours < 1 / 60) return "أقل من دقيقة";
	if (hours < 1) return `${Math.round(hours * 60)} دقيقة`;
	const whole = Math.floor(hours);
	const minutes = Math.round((hours - whole) * 60);
	if (minutes === 0) return `${whole} ساعة`;
	return `${whole} ساعة و ${minutes} دقيقة`;
}
function formatDays(days) {
	if (days < 1) return "أقل من يوم تشغيل";
	const whole = Math.floor(days);
	const rest = Math.round((days - whole) * 10) / 10;
	if (rest <= .05) return `${whole} يوم تشغيل`;
	return `${whole + rest} يوم تشغيل`;
}
function makeSecondsFor(scenario, drive, product, nps, lengthM) {
	if (product === "cover") return calcTime(scenario, drive, lengthM, scenario.stripWidthMm != null && scenario.coverOverlapMm != null ? scenario.stripWidthMm - scenario.coverOverlapMm : null, nps).totalSec;
	if (product === "joint") return calcTime(scenario, drive, lengthM, scenario.pitchMm, nps).totalSec;
	const inner = calcTime(scenario, drive, lengthM, scenario.pitchMm, nps);
	const coverNps = scenario.schCover[nps] ?? "";
	const pitch = scenario.stripWidthMm != null && scenario.coverOverlapMm != null ? scenario.stripWidthMm - scenario.coverOverlapMm : null;
	const outer = coverNps ? calcTime(scenario, drive, lengthM, pitch, coverNps) : null;
	if (inner.totalSec == null || outer?.totalSec == null) return null;
	const extra = drive.extraSec != null && drive.extraSec > 0 ? drive.extraSec : 0;
	return inner.totalSec + outer.totalSec - extra;
}
var fieldClass = "h-11 w-full rounded-lg border border-line bg-card px-3 text-sm text-ink shadow-card outline-none transition-[border-color] duration-150 focus:border-copper";
function Card({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `rounded-2xl bg-card p-4 shadow-card ${className}`,
		children
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mb-1 block text-sm font-medium text-ink",
		children
	});
}
function Hint({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "mt-1 block text-xs leading-5 text-muted",
		children
	});
}
function NumberField({ label, value, onChange, unit, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: label }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: `${fieldClass} font-mono tabular-nums`,
					dir: "ltr",
					inputMode: "decimal",
					autoComplete: "off",
					value,
					onChange: (event) => onChange(event.target.value)
				}), unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs text-muted",
					children: unit
				}) : null]
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, { children: hint }) : null
		]
	});
}
function SelectField({ label, value, onChange, options, hint, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: `block ${disabled ? "opacity-50" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: label }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: fieldClass,
				value,
				disabled,
				onChange: (event) => onChange(event.target.value),
				children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: option.value,
					children: option.label
				}, option.value))
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, { children: hint }) : null
		]
	});
}
function TextField({ label, value, onChange, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: label }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: fieldClass,
				value,
				onChange: (event) => onChange(event.target.value)
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, { children: hint }) : null
		]
	});
}
function Readout({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: label }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "flex h-11 items-center rounded-lg bg-paper-2 px-3 font-mono text-sm tabular-nums text-ink",
			dir: "ltr",
			children: value
		}),
		hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, { children: hint }) : null
	] });
}
function StatusBanner({ issues, okText }) {
	const bad = issues.filter((issue) => issue.tone === "bad");
	const warnings = issues.filter((issue) => issue.tone === "warn");
	if (bad.length === 0 && warnings.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 rounded-xl bg-ok-bg px-3 py-2 text-sm font-medium text-ok",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
			className: "size-4 shrink-0",
			"aria-hidden": "true"
		}), okText]
	});
	const list = bad.length > 0 ? bad : warnings;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-warn-bg px-3 py-2 text-sm text-warn",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-2 font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "size-4 shrink-0",
				"aria-hidden": "true"
			}), bad.length > 0 ? "راجع المدخلات" : "تنبيه"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1 space-y-1 ps-6",
			children: list.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: issue.text }, issue.text))
		})]
	});
}
function HeroStat({ label, value, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-paper px-3 py-3 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 font-mono text-xl font-semibold tabular-nums text-ink",
			dir: "ltr",
			children: [value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-1 text-xs font-medium text-muted",
				children: unit
			})]
		})]
	});
}
function DetailRow({ label, value, unit, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-3 border-b border-line py-2 last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink",
				children: label
			}), note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: note
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "shrink-0 font-mono text-sm font-medium tabular-nums text-ink",
			dir: "ltr",
			children: [value, unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-1 text-xs font-normal text-muted",
				children: unit
			}) : null]
		})]
	});
}
function WeightBar({ parts }) {
	const total = parts.reduce((sum, part) => sum + (part.grams != null && part.grams > 0 ? part.grams : 0), 0);
	if (total <= 0) return null;
	const toneClass = {
		steel: "bg-steel",
		copper: "bg-copper",
		ink: "bg-ink",
		ok: "bg-ok"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-2.5 overflow-hidden rounded-full bg-paper-2",
		children: parts.map((part) => part.grams != null && part.grams > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: toneClass[part.tone],
			style: { width: `${part.grams / total * 100}%` }
		}, part.label) : null)
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 flex flex-wrap gap-x-3 gap-y-1",
		children: parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-1 text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${toneClass[part.tone]}` }), part.label]
		}, part.label))
	})] });
}
function useDigits() {
	const precision = useFlex((state) => state.precision);
	return (value, kind = "n") => {
		if (value == null || !Number.isFinite(value)) return "—";
		if (precision) return fmt(value, 6, 0);
		if (kind === "money") return fmt(value, 2, 2);
		if (kind === "g") return fmt(value, 2, 2);
		if (kind === "len") return fmt(value, 3, 3);
		if (kind === "mm") return fmt(value, 2, 0);
		return fmt(value, 3, 0);
	};
}
function moneyText(value, currency, digits) {
	if (value == null) return "غير مكتمل";
	return `${digits(value, "money")} ${currency}`;
}
function usePack() {
	const state = useFlex();
	const scenario = toScenario(state);
	const joint = calcJoint(scenario, scenario.jointLengthM, scenario.jointNps);
	const cover = calcCover(scenario);
	const insulated = calcInsulated(scenario);
	return {
		state,
		scenario,
		joint,
		cover,
		insulated,
		cost: calcCost(scenario, joint, cover, insulated)
	};
}
var npsOptions$3 = SCH40.map((row) => ({
	value: row.nps,
	label: `${row.nps}″`
}));
var wireOptions = WIRES.map((wire) => ({
	value: wire.key,
	label: wire.label
}));
var matOptions = MATERIALS.map((mat) => ({
	value: mat.id,
	label: mat.name
}));
function recipeLine(state) {
	const wire = wireByKey(state.joint.wireKey);
	const mat = materialById(state.joint.material1);
	return `${state.joint.layerType === "double" ? "Double layer" : "Single layer"} · ${wire?.label ?? "سلك"} · خطوة ${state.joint.pitchMm} مم · ${mat?.name ?? ""}`;
}
function JointPanel() {
	const { state, joint, scenario } = usePack();
	const digits = useDigits();
	const per = (value) => {
		const len = scenario.jointLengthM;
		if (value == null || len == null || len <= 0) return null;
		return value / len;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[22rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-ink",
				children: "مدخلات الوصلة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "عدّل الطول والمقاس والسلك والخامة. التداخل والقطر يتحسبان وحدهم."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "طول الوصلة",
						unit: "م",
						value: state.joint.lengthM,
						onChange: (lengthM) => state.patchJoint({ lengthM }),
						hint: "طول الوصلة النهائية بالمتر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "مقاس الماسورة الاسمي NPS",
						value: state.joint.nps,
						onChange: (nps) => state.patchJoint({ nps }),
						options: npsOptions$3,
						hint: joint.idMm == null ? "من جدول Sch 40" : `القطر الداخلي المعتمد ${digits(joint.idMm, "mm")} مم`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-sm font-medium text-ink",
						children: "نوع الوصلة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-1 rounded-lg bg-paper-2 p-1",
						children: [["single", "طبقة واحدة"], ["double", "طبقتان"]].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": state.joint.layerType === value,
							className: `h-11 rounded-md text-sm font-medium ${state.joint.layerType === value ? "bg-card text-ink shadow-card" : "text-muted"}`,
							onClick: () => state.patchJoint({ layerType: value }),
							children: label
						}, value))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "قطر السلك",
						value: state.joint.wireKey,
						onChange: (wireKey) => state.patchJoint({ wireKey }),
						options: wireOptions
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "خطوة السلك",
							unit: "مم",
							value: state.joint.pitchMm,
							onChange: (pitchMm) => state.patchJoint({ pitchMm })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "عرض الشريط",
							unit: "مم",
							value: state.joint.stripWidthMm,
							onChange: (stripWidthMm) => state.patchJoint({ stripWidthMm })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {
						label: "التداخل",
						value: joint.overlapMm == null ? "—" : `${digits(joint.overlapMm, "mm")} مم`,
						hint: "عرض الشريط − الخطوة، ويُلصق بالغراء"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "خامة الطبقة الأولى",
						value: state.joint.material1,
						onChange: (material1) => state.patchJoint({ material1 }),
						options: matOptions
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "خامة الطبقة الثانية",
						value: state.joint.material2,
						disabled: state.joint.layerType !== "double",
						onChange: (material2) => state.patchJoint({ material2 }),
						options: matOptions,
						hint: state.joint.layerType === "double" ? "تُحسب بنفس طول الشريط" : "تُستخدم فقط في Double layer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "غراء مرجعي",
							unit: "جم/م",
							value: state.joint.glueGPerM,
							onChange: (glueGPerM) => state.patchJoint({ glueGPerM })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "تداخل الغراء",
							unit: "مم",
							value: state.joint.glueRefOverlapMm,
							onChange: (glueRefOverlapMm) => state.patchJoint({ glueRefOverlapMm })
						})]
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid content-start gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
					issues: joint.issues,
					okText: "المدخلات سليمة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "طول السلك",
							value: digits(joint.wire?.lengthM ?? null, "len"),
							unit: "م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "طول الخامة / طبقة",
							value: digits(joint.strip?.lengthM ?? null, "len"),
							unit: "م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن الوصلة",
							value: digits(joint.totalG, "g"),
							unit: "جم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن المتر",
							value: digits(joint.perMeterG, "g"),
							unit: "جم/م"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: "توزيع الوزن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeightBar, { parts: [
							{
								label: "السلك",
								grams: joint.wireWeightG,
								tone: "steel"
							},
							{
								label: "الطبقة الأولى",
								grams: joint.layer1G,
								tone: "copper"
							},
							{
								label: "الطبقة الثانية",
								grams: joint.layer2G,
								tone: "ink"
							},
							{
								label: "الغراء",
								grams: joint.glueG,
								tone: "ok"
							}
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "عدد اللفات",
								value: digits(joint.turns, "n"),
								unit: "لفة",
								note: "طول الوصلة ÷ الخطوة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "طول السلك",
								value: digits(joint.wire?.lengthM ?? null, "len"),
								unit: "م",
								note: "لفّة حلزونية على القطر الداخلي + تخانة السلك"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "طول الخامة لكل طبقة",
								value: digits(joint.strip?.lengthM ?? null, "len"),
								unit: "م",
								note: "نفس الخطوة، فوق السلك بقطر أكبر"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "عدد الطبقات",
								value: String(joint.layers),
								unit: "طبقة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "إجمالي طول الخامة",
								value: digits(joint.totalStripM, "len"),
								unit: "م"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "وزن السلك",
								value: digits(joint.wireWeightG, "g"),
								unit: "جم"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "وزن الطبقة الأولى",
								value: digits(joint.layer1G, "g"),
								unit: "جم",
								note: materialById(state.joint.material1)?.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "وزن الطبقة الثانية",
								value: digits(joint.layer2G, "g"),
								unit: "جم",
								note: joint.layers === 2 ? materialById(state.joint.material2)?.name : "صفر في Single layer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الغراء لكل متر شريط",
								value: digits(joint.gluePerM, "n"),
								unit: "جم/م"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "وزن الغراء",
								value: digits(joint.glueG, "g"),
								unit: "جم"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "إجمالي الوزن",
								value: digits(joint.totalKg, "n"),
								unit: "كجم"
							})
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold text-ink",
					children: "استهلاك كل متر وصلة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
							label: "السلك",
							value: digits(per(joint.wire?.lengthM ?? null), "len"),
							unit: "م/م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
							label: "الخامة لكل طبقة",
							value: digits(per(joint.strip?.lengthM ?? null), "len"),
							unit: "م/م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
							label: "الغراء",
							value: digits(per(joint.glueG), "g"),
							unit: "جم/م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
							label: "الوزن",
							value: digits(joint.perMeterG, "g"),
							unit: "جم/م"
						})
					]
				})] })
			]
		})]
	});
}
function CoverPanel() {
	const { state, cover } = usePack();
	const digits = useDigits();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[22rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-ink",
				children: "مدخلات الـ Cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					"لفّ حلزوني بالخامة والغراء بدون سلك. عرض الشريط من مدخلات الوصلة (",
					state.joint.stripWidthMm,
					" مم)."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "طول الـ Cover",
						unit: "م",
						value: state.cover.lengthM,
						onChange: (lengthM) => state.patchCover({ lengthM })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "مقاس الـ Cover الاسمي NPS",
						value: state.cover.nps,
						onChange: (nps) => state.patchCover({ nps }),
						options: npsOptions$3,
						hint: cover.idMm == null ? void 0 : `القطر الداخلي ${digits(cover.idMm, "mm")} مم`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "خامة الـ Cover",
						value: state.cover.material,
						onChange: (material) => state.patchCover({ material }),
						options: matOptions,
						hint: "تُستخدم أيضًا في الوصلة المعزولة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "التداخل",
						unit: "مم",
						value: state.cover.overlapMm,
						onChange: (overlapMm) => state.patchCover({ overlapMm }),
						hint: "يُستخدم أيضًا في الوصلة المعزولة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {
						label: "خطوة لفّ الخامة",
						value: cover.pitchMm == null ? "—" : `${digits(cover.pitchMm, "mm")} مم`,
						hint: "عرض الشريط − التداخل"
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid content-start gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
					issues: cover.issues,
					okText: "مدخلات الـ Cover سليمة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "طول الخامة",
							value: digits(cover.stripM, "len"),
							unit: "م"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن الخامة",
							value: digits(cover.matWeightG, "g"),
							unit: "جم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن الغراء",
							value: digits(cover.glueG, "g"),
							unit: "جم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "إجمالي الـ Cover",
							value: digits(cover.totalG, "g"),
							unit: "جم"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "عدد اللفات",
						value: digits(cover.turns, "n"),
						unit: "لفة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "طول الخامة",
						value: digits(cover.stripM, "len"),
						unit: "م",
						note: materialById(state.cover.material)?.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "الغراء لكل متر",
						value: digits(cover.gluePerM, "n"),
						unit: "جم/م"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "وزن المتر",
						value: digits(cover.perMeterG, "g"),
						unit: "جم/م"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "الإجمالي",
						value: digits(cover.totalKg, "n"),
						unit: "كجم"
					})
				] })
			]
		})]
	});
}
function InsulatedPanel() {
	const { state, insulated } = usePack();
	const digits = useDigits();
	const setSection = useFlex((s) => s.setSection);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[22rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-ink",
				children: "الوصلة المعزولة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "من الداخل: وصلة بسلك وخامة، ثم صوف زجاجي، ثم Cover أكبر بدرجة."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "طول الوصلة المراد عزلها",
						unit: "م",
						value: state.insulated.lengthM,
						onChange: (lengthM) => state.patchInsulated({ lengthM })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "مقاس الوصلة NPS",
						value: state.insulated.nps,
						onChange: (nps) => state.patchInsulated({ nps }),
						options: npsOptions$3,
						hint: insulated.coverNps ? `الـ Cover المناسب ${insulated.coverNps}″ — قطر ${digits(insulated.coverIdMm, "mm")} مم` : "مقاس الـ Cover ناقص في جدول Sch 40"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-paper px-3 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-ink",
								children: "تركيب الوصلة الداخلية"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: recipeLine(state)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-sm font-medium text-copper",
								onClick: () => setSection("joint"),
								children: "تعديل من تبويب الوصلة"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-paper px-3 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-ink",
								children: "خامة الغطاء وتداخله"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-muted",
								children: [
									materialById(state.cover.material)?.name,
									" · تداخل ",
									state.cover.overlapMm,
									" مم"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-sm font-medium text-copper",
								onClick: () => setSection("cover"),
								children: "تعديل من تبويب الغطاء"
							})
						]
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid content-start gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
					issues: insulated.issues,
					okText: "الأبعاد سليمة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "سمك العزل",
							value: digits(insulated.insulationMm, "mm"),
							unit: "مم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن الصوف",
							value: digits(insulated.woolG, "g"),
							unit: "جم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "وزن الغطاء",
							value: digits(insulated.coverTotalG, "g"),
							unit: "جم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "الإجمالي",
							value: digits(insulated.totalG, "g"),
							unit: "جم"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: "من الداخل للخارج"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "قطر الوصلة الداخلي",
						value: digits(insulated.idMm, "mm"),
						unit: "مم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "القطر الخارجي للوصلة",
						value: digits(insulated.outerMm, "mm"),
						unit: "مم",
						note: "ID + 2 × قطر السلك"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "قطر الـ Cover",
						value: digits(insulated.coverIdMm, "mm"),
						unit: "مم",
						note: insulated.coverNps ? `NPS ${insulated.coverNps}` : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "سمك العزل الناتج",
						value: digits(insulated.insulationMm, "mm"),
						unit: "مم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "وزن الوصلة الداخلية",
						value: digits(insulated.inner?.totalG ?? null, "g"),
						unit: "جم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "وزن الصوف للمتر المربع",
						value: digits(insulated.woolGPerM2, "g"),
						unit: "جم/م²",
						note: "السمك × الكثافة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "عرض الصوف (الانفراد)",
						value: digits(insulated.woolWidthMm, "mm"),
						unit: "مم",
						note: "محيط الـ Cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "مساحة الصوف",
						value: digits(insulated.woolAreaM2, "n"),
						unit: "م²"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "طول خامة الـ Cover",
						value: digits(insulated.coverStripM, "len"),
						unit: "م"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "وزن غراء الـ Cover",
						value: digits(insulated.coverGlueG, "g"),
						unit: "جم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "وزن المتر المعزول",
						value: digits(insulated.perMeterG, "g"),
						unit: "جم/م"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "الإجمالي",
						value: digits(insulated.totalKg, "n"),
						unit: "كجم"
					})
				] })
			]
		})]
	});
}
function PriceEditor({ priceKey, label, note, allow, basisG }) {
	const price = useFlex((state) => state.prices[priceKey] ?? {
		price: "",
		unit: "kg"
	});
	const setPrice = useFlex((state) => state.setPrice);
	const currency = useFlex((state) => state.currency);
	const unitLabel = {
		kg: `${currency}/كجم`,
		m: `${currency}/متر`,
		m2: `${currency}/م²`
	};
	const entered = num(price.price);
	const perMeter = entered == null ? null : price.unit === "m" ? entered : price.unit === "kg" && basisG != null && basisG > 0 ? entered * basisG / 1e3 : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2 border-b border-line py-3 last:border-b-0 sm:grid-cols-[minmax(0,1fr)_8rem_9rem] sm:items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap items-center gap-2 text-sm font-medium text-ink",
					children: [label, entered == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-warn-bg px-2 py-0.5 text-xs font-medium text-warn",
						children: "بانتظار السعر"
					}) : null]
				}),
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: note
				}) : null,
				perMeter != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					dir: "ltr",
					children: [
						perMeter.toFixed(4),
						" ",
						currency,
						"/m"
					]
				}) : null
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `${fieldClass} font-mono tabular-nums`,
				dir: "ltr",
				inputMode: "decimal",
				placeholder: "السعر",
				value: price.price,
				onChange: (event) => setPrice(priceKey, { price: event.target.value })
			}),
			allow.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: fieldClass,
				value: price.unit,
				onChange: (event) => setPrice(priceKey, { unit: event.target.value }),
				children: allow.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: unit,
					children: unitLabel[unit]
				}, unit))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: unitLabel[allow[0] ?? "kg"]
			})
		]
	});
}
function CostLines({ lines, currency }) {
	const digits = useDigits();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
		label: line.label,
		value: line.cost == null ? "غير مكتمل" : digits(line.cost, "money"),
		unit: line.cost == null ? void 0 : currency,
		note: `${line.chosen}${line.qty != null ? ` · ${digits(line.qty, "n")} ${line.unit}` : ""}`
	}, line.id)) });
}
function CostPanel() {
	const { state, cost } = usePack();
	const digits = useDigits();
	const currency = state.currency || "جنيه";
	const focusMissing = state.costFocus === "cover" ? cost.coverMissing : state.costFocus === "insulated" ? cost.insMissing : cost.jointMissing;
	const focusMaterial = state.costFocus === "cover" ? cost.coverTotal : state.costFocus === "insulated" ? cost.insTotal : cost.jointMaterial;
	const focusName = state.costFocus === "cover" ? "الـ Cover" : state.costFocus === "insulated" ? "الوصلة المعزولة" : "الوصلة";
	const missing = focusMissing.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "أسعار الخامات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "أسعار الشيت معبّأة حيث وُجدت. الخانة الفاضية تبقى بانتظار سعرك، وتقدر تعدّل أي سعر. البنود الأخرى الفاضية لا تدخل في الإجمالي."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg bg-copper px-3 text-sm font-semibold text-copper-ink",
							onClick: () => state.restoreSheetPrices(),
							children: "استعادة أسعار الشيت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 rounded-lg bg-paper px-3 text-sm font-medium text-ink shadow-card",
							onClick: () => state.clearPrices(),
							children: "مسح الأسعار"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 max-w-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						label: "العملة",
						value: state.currency,
						onChange: state.setCurrency
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2",
					children: [
						WIRES.map((wire) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceEditor, {
							priceKey: priceKeyWire(wire.key),
							label: wire.label,
							note: state.wireG[wire.key] ? `${state.wireG[wire.key]} جم/م` : "وزن المتر ناقص — أدخله في الجداول",
							allow: ["kg", "m"],
							basisG: num(state.wireG[wire.key])
						}, wire.key)),
						MATERIALS.map((mat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceEditor, {
							priceKey: priceKeyMat(mat.id),
							label: mat.name,
							note: `${state.matG[mat.id] || "—"} جم/م · عرض 5 سم`,
							allow: ["kg", "m"],
							basisG: num(state.matG[mat.id])
						}, mat.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceEditor, {
							priceKey: "glue",
							label: "الغراء (Water base acrylic)",
							note: "السعر لكل كيلوجرام، والتكلفة تُحسب بالجرام",
							allow: ["kg"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceEditor, {
							priceKey: "wool",
							label: "الصوف الزجاجي",
							note: "السعر للكيلو أو للمتر المربع. لو فاضي، تكلفة الوصلة المعزولة تظل غير مكتملة لحد ما تدخله.",
							allow: ["kg", "m2"]
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: [
					[
						"joint",
						"الوصلة",
						cost.jointMaterial
					],
					[
						"cover",
						"الـ Cover",
						cost.coverTotal
					],
					[
						"insulated",
						"الوصلة المعزولة",
						cost.insTotal
					]
				].map(([id, label, material]) => {
					const active = state.costFocus === id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": active,
						className: `rounded-2xl px-3 py-3 text-start shadow-card ${active ? "bg-steel text-steel-ink" : "bg-card text-ink"}`,
						onClick: () => state.setCostFocus(id),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-xs ${active ? "text-steel-ink/75" : "text-muted"}`,
								children: "تكاليف كاملة لـ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm font-semibold",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-mono text-lg font-semibold tabular-nums",
								dir: "ltr",
								children: material == null ? "خامات ناقصة" : digits(material, "money")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `text-xs ${active ? "text-steel-ink/70" : "text-muted"}`,
								children: "خامات فقط · اضغط لاختيار الربح والتكاليف الأخرى"
							})
						]
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "خامات الوصلة الحالية"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							wireByKey(state.joint.wireKey)?.label,
							" · ",
							materialById(state.joint.material1)?.name,
							state.joint.layerType === "double" ? ` + ${materialById(state.joint.material2)?.name}` : " · Single layer"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostLines, {
						lines: cost.jointLines,
						currency
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "إجمالي تكلفة الخامات",
						value: cost.jointMaterial == null ? "غير مكتمل" : digits(cost.jointMaterial, "money"),
						unit: cost.jointMaterial == null ? void 0 : currency,
						note: missing > 0 ? `ينقص سعر ${missing} من الخامات المستخدمة` : "مكتمل"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-steel p-4 text-steel-ink shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-steel-ink/80",
							children: ["سعر بيع ", focusName]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-3xl font-semibold tabular-nums",
							dir: "ltr",
							children: cost.sell == null ? "—" : digits(cost.sell, "money")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-steel-ink/80",
							children: currency
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "تكلفة الخامات"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: moneyText(focusMaterial, currency, digits)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "الكرتونة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: cost.carton?.missingPrice ? "بانتظار السعر" : moneyText(cost.carton?.costPerPiece ?? null, currency, digits)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "تكاليف أخرى"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: moneyText(cost.extrasTotal, currency, digits)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "إجمالي التكلفة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: moneyText(cost.total, currency, digits)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "الربح"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: moneyText(cost.profit, currency, digits)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "تكلفة المتر"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: cost.costPerM == null ? "—" : `${digits(cost.costPerM, "money")} /م`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-steel-ink/75",
										children: "سعر بيع المتر"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-mono tabular-nums",
										dir: "ltr",
										children: cost.sellPerM == null ? "—" : `${digits(cost.sellPerM, "money")} /م`
									})]
								})
							]
						}),
						cost.carton ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-steel-ink/70",
							children: [
								"الكرتونة ",
								cost.carton.lengthMm == null ? "—" : `${Math.round(cost.carton.lengthMm)}×${Math.round(cost.carton.widthMm ?? 0)}×${Math.round(cost.carton.heightMm ?? 0)} مم`,
								cost.carton.missingPrice ? " — سعر المقاس غير مُدخل ولا يدخل في الإجمالي." : " · السعر داخل التكلفة."
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-1 block text-xs text-steel-ink/75",
								children: "نسبة الربح على التكلفة %"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-11 w-full rounded-lg bg-card px-3 font-mono text-sm text-ink tabular-nums outline-none",
								dir: "ltr",
								inputMode: "decimal",
								placeholder: "20",
								value: state.marginPct,
								onChange: (event) => state.setMargin(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-steel-ink/70",
							children: [missing > 0 ? `ينقص سعر ${missing} من خامات ${focusName} — الإجمالي غير مكتمل.` : `خامات ${focusName} مكتملة.`, cost.extrasSkipped > 0 ? ` ${cost.extrasSkipped} بند تكاليف أخرى فاضي ولا يدخل.` : ""]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-ink",
					children: "تكاليف أخرى"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: "البند الفاضي لا يُحسب. النسبة تُحسب من تكلفة خامات المنتج المختار فوق."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3",
					children: state.extras.map((extra) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_7rem_11rem_auto] sm:items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: fieldClass,
								value: extra.label,
								onChange: (event) => state.setExtra(extra.id, { label: event.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${fieldClass} font-mono tabular-nums`,
								dir: "ltr",
								inputMode: "decimal",
								placeholder: "القيمة",
								value: extra.value,
								onChange: (event) => state.setExtra(extra.id, { value: event.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: fieldClass,
								value: extra.basis,
								onChange: (event) => state.setExtra(extra.id, { basis: event.target.value }),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "pct",
										children: "% من الخامات"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "per_m",
										children: [currency, "/متر"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: "per_piece",
										children: [currency, "/قطعة"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "inline-flex h-11 items-center justify-center gap-1 rounded-lg px-3 text-sm text-warn",
								onClick: () => state.removeExtra(extra.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "حذف"]
							})
						]
					}, extra.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-3 inline-flex h-11 items-center gap-2 text-sm font-medium text-copper",
					onClick: () => state.addExtra(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						"aria-hidden": "true"
					}), "بند جديد"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
					label: "إجمالي التكاليف الأخرى",
					value: cost.extrasTotal == null ? "غير مكتمل" : digits(cost.extrasTotal, "money"),
					unit: cost.extrasTotal == null ? void 0 : currency
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "تكلفة الـ Cover المستقل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "خامات فقط. اختر الـ Cover من الأزرار فوق لتدخل التكاليف الأخرى والربح والكرتونة."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostLines, {
						lines: cost.coverLines,
						currency
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "الإجمالي",
						value: cost.coverTotal == null ? "غير مكتمل" : digits(cost.coverTotal, "money"),
						unit: cost.coverTotal == null ? void 0 : currency,
						note: cost.coverMissing.length > 0 ? `ناقص ${cost.coverMissing.length}` : void 0
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "تكلفة خامات الوصلة المعزولة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "خامات فقط. سعر الصوف إن كان فاضيًا يوقف الإجمالي. اختر الوصلة المعزولة فوق لحساب الربح والتكاليف الأخرى."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostLines, {
						lines: cost.insLines,
						currency
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "إجمالي الخامات",
						value: cost.insTotal == null ? "غير مكتمل" : digits(cost.insTotal, "money"),
						unit: cost.insTotal == null ? void 0 : currency
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "تكلفة المتر المعزول",
						value: cost.insPerM == null ? "—" : digits(cost.insPerM, "money"),
						unit: cost.insPerM == null ? void 0 : `${currency}/م`
					})
				] })]
			})
		]
	});
}
function TablesPanel() {
	const state = useFlex();
	const digits = useDigits();
	const woolThk = Number(state.wool.thicknessMm);
	const woolDen = Number(state.wool.density);
	const woolGsm = Number.isFinite(woolThk) && Number.isFinite(woolDen) ? woolThk * woolDen : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-ink",
					children: "جدول Sch 40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-xs text-muted",
					children: "القطر المعتمد = ID التصنيع إن وُجد، وإلا OD − 2 × سمك الجدار. مقاس 5 بوصة ناقص Cover في الإكسيل — اكتبه هنا."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-lg bg-paper px-3 text-sm font-medium text-ink shadow-card",
					onClick: () => state.resetTables(),
					children: "استعادة الجدول"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] border-separate border-spacing-0 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-start text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "NPS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "OD مم"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "الجدار"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "ID محسوب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "ID تصنيع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line px-2 py-2 font-medium",
								children: "Cover"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SCH40.map((spec) => {
						const draft = state.sch.find((row) => row.nps === spec.nps);
						const actual = draft?.actualId ?? "";
						const adopted = approvedId(spec.nps, actual);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "border-b border-line px-2 py-1.5 font-medium",
								children: [spec.nps, "″"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line px-2 py-1.5 font-mono tabular-nums",
								dir: "ltr",
								children: spec.od
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line px-2 py-1.5 font-mono tabular-nums",
								dir: "ltr",
								children: spec.wall
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line px-2 py-1.5 font-mono tabular-nums",
								dir: "ltr",
								children: digits(geometricId(spec), "mm")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line px-2 py-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "h-10 w-24 rounded-lg border border-line bg-card px-2 font-mono text-sm tabular-nums",
									dir: "ltr",
									inputMode: "decimal",
									placeholder: adopted == null ? "" : String(geometricId(spec)),
									value: actual,
									onChange: (event) => state.setSchField(spec.nps, "actualId", event.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line px-2 py-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-10 rounded-lg border border-line bg-card px-2 text-sm",
									value: draft?.coverNps ?? "",
									onChange: (event) => state.setSchField(spec.nps, "coverNps", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "—"
									}), SCH40.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: option.nps,
										children: [option.nps, "″"]
									}, option.nps))]
								})
							})
						] }, spec.nps);
					}) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "وزن السلك"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "0.9 و 1.2 و 1.4 فاضيين في الإكسيل. التقدير من مربع القطر على أقرب وزن مُقاس."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 shrink-0 rounded-lg bg-copper px-3 text-sm font-semibold text-copper-ink",
						onClick: () => state.estimateWires(),
						children: "تقدير الناقص"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-3",
					children: WIRES.map((wire) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: wire.label,
						unit: "جم/م",
						value: state.wireG[wire.key] ?? "",
						onChange: (value) => state.setWireG(wire.key, value),
						hint: wire.gPerM == null ? "غير مُدخل في الإكسيل" : "قيمة الإكسيل"
					}, wire.key))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold text-ink",
						children: "وزن الخامات والصوف"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "كل الأشرطة عرضها 5 سم."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3",
						children: [
							MATERIALS.map((mat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: mat.name,
								unit: "جم/م",
								value: state.matG[mat.id] ?? "",
								onChange: (value) => state.setMatG(mat.id, value)
							}, mat.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "سمك الصوف",
									unit: "مم",
									value: state.wool.thicknessMm,
									onChange: (thicknessMm) => state.patchWool({ thicknessMm })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
									label: "الكثافة",
									unit: "كجم/م³",
									value: state.wool.density,
									onChange: (density) => state.patchWool({ density })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {
								label: "وزن المتر المربع",
								value: woolGsm == null ? "—" : `${digits(woolGsm, "g")} جم/م²`,
								hint: "السمك بالمم × الكثافة"
							})
						]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartonTable, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-ink",
					children: "افتراضات الإكسيل"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-2 list-disc space-y-1 ps-5 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "في الطبقتين يُحسب نفس طول الشريط، وسمك الرقائق مُهمل." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الغراء 0.22 جم لكل متر شريط عند تداخل 15 مم، ويتناسب مع التداخل، ويُحسب لكل طبقة." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الوصلة المعزولة لها طولها ومقاسها، وتركيبها الداخلي من مدخلات الوصلة." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الصوف الافتراضي 25 مم وكثافة 16 كجم/م³، أي 400 جم/م². انفراد الصوف = محيط الـ Cover." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "سلك الوصلة يُلف على ID + تخانة السلك، والشريط على ID + ضعف التخانة، والغطاء على قطره بلا سلك." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "لا يُحسب الهالك إلا إذا كُتبت نسبته في التكاليف، والبنود الفاضية لا تدخل في الإجمالي." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الكرتونة: الطول والعرض = قطر المنتج + 50 مم، والارتفاع 400 مم للوصلة والـ Cover و1000 مم للوصلة المعزولة. سعر الكرتونة اختياري." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "زمن التصنيع من سرعة الماتور والتردد ونسبة الجيربوكس وقطر الطنبورة، بعد خصم فريز الـ Head." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"مقاس ",
						schByNps("5")?.nps,
						"″ غطاؤه غير مكتوب في الملف الأصلي. راجع أبعاد المورد قبل الشراء."
					]
				})
			] })
		]
	});
}
function CartonTable() {
	const state = useFlex();
	const [product, setProduct] = (0, import_react.useState)("joint");
	const rows = CARTON_SIZES.filter((row) => row.product === product);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-base font-semibold text-ink",
			children: "كراتين التغليف"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 max-w-2xl text-xs text-muted",
			children: "الطول والعرض = القطر + 5 سم، والارتفاع 40 سم. الوصلة المعزولة ارتفاعها متر. اكتب السعر لما يتوفر، واترك البعد فاضيًا لو عايز الحساب التلقائي."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 grid grid-cols-3 gap-1 rounded-lg bg-paper-2 p-1",
			children: [
				"joint",
				"cover",
				"insulated"
			].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": product === id,
				className: `h-11 rounded-md text-sm font-medium ${product === id ? "bg-card text-ink shadow-card" : "text-muted"}`,
				onClick: () => setProduct(id),
				children: productLabel(id)
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[46rem] border-separate border-spacing-0 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-start text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "المقاس"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "الطول مم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "العرض مم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "الارتفاع مم"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "قطع/كرتونة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "border-b border-line px-2 py-2 font-medium",
							children: "سعر الكرتونة"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => {
					const key = cartonKey(row.product, row.nps);
					const draft = state.cartons[key];
					const diameter = cartonDiameter(state.sch, row.product, row.nps);
					const auto = diameter == null ? null : autoCartonMm(row.product, diameter);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "border-b border-line px-2 py-1.5 font-medium",
							children: [row.nps, "″"]
						}),
						[
							"lengthMm",
							"widthMm",
							"heightMm"
						].map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-2 py-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-10 w-24 rounded-lg border border-line bg-card px-2 font-mono text-sm tabular-nums",
								dir: "ltr",
								inputMode: "decimal",
								placeholder: auto == null ? "—" : String(Math.round(auto[field])),
								value: draft?.[field] ?? "",
								onChange: (event) => state.patchCarton(key, { [field]: event.target.value })
							})
						}, field)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-2 py-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-10 w-20 rounded-lg border border-line bg-card px-2 font-mono text-sm tabular-nums",
								dir: "ltr",
								inputMode: "decimal",
								placeholder: "1",
								value: draft?.pieces ?? "1",
								onChange: (event) => state.patchCarton(key, { pieces: event.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line px-2 py-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-10 w-28 rounded-lg border border-line bg-card px-2 font-mono text-sm tabular-nums",
								dir: "ltr",
								inputMode: "decimal",
								placeholder: "بانتظار السعر",
								value: draft?.price ?? "",
								onChange: (event) => state.patchCarton(key, { price: event.target.value })
							})
						})
					] }, key);
				}) })]
			})
		})
	] });
}
function cartonDiameter(sch, product, nps) {
	const row = sch.find((item) => item.nps === nps);
	if (product === "insulated") {
		const coverNps = row?.coverNps ?? "";
		if (!coverNps) return null;
		return approvedId(coverNps, sch.find((item) => item.nps === coverNps)?.actualId ?? "");
	}
	return approvedId(nps, row?.actualId ?? "");
}
function summaryText(pack, currency) {
	const { state, joint, cover, insulated, cost } = pack;
	const n = (value, d = 3) => value == null || !Number.isFinite(value) ? "—" : value.toFixed(d);
	const lines = [
		`حاسبة الفليكسيبل`,
		`وصلة ${state.joint.nps}" × ${state.joint.lengthM} م · ${state.joint.layerType === "double" ? "Double" : "Single"} · ${wireByKey(state.joint.wireKey)?.label}`,
		`سلك ${n(joint.wire?.lengthM)} م (${n(joint.wireWeightG, 2)} جم)`,
		`خامة/طبقة ${n(joint.strip?.lengthM)} م (${n(joint.layer1G, 2)} جم)`,
		`غراء ${n(joint.glueG, 2)} جم`,
		`وزن الوصلة ${n(joint.totalG, 2)} جم · ${n(joint.perMeterG, 2)} جم/م`,
		`Cover ${state.cover.nps}" × ${state.cover.lengthM} م · ${n(cover.totalG, 2)} جم`,
		`معزولة ${state.insulated.nps}" × ${state.insulated.lengthM} م · عزل ${n(insulated.insulationMm, 1)} مم · ${n(insulated.totalG, 2)} جم`
	];
	if (cost.sell != null) lines.push(`سعر البيع ${cost.sell.toFixed(2)} ${currency}`);
	else if (cost.jointMissing.length > 0) lines.push(`التكلفة غير مكتملة — ينقص ${cost.jointMissing.length} سعر`);
	return lines.join("\n");
}
function PrintReport() {
	const pack = usePack();
	const digits = useDigits();
	const { joint, cover, insulated, cost, state } = pack;
	const currency = state.currency || "جنيه";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "only-print mx-auto max-w-3xl bg-card p-6 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-semibold",
				children: "حاسبة الفليكسيبل"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "وصلات ألومنيوم حلزونية — بيان استهلاك وتكلفة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-4 text-lg font-semibold",
				children: [
					"الوصلة ",
					state.joint.nps,
					"″ × ",
					state.joint.lengthM,
					" م"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: recipeLine(state)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "طول السلك",
				value: digits(joint.wire?.lengthM ?? null, "len"),
				unit: "م"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "طول الخامة لكل طبقة",
				value: digits(joint.strip?.lengthM ?? null, "len"),
				unit: "م"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "الوزن",
				value: digits(joint.totalG, "g"),
				unit: "جم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "سعر البيع",
				value: cost.sell == null ? "غير مكتمل" : digits(cost.sell, "money"),
				unit: currency
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-4 text-lg font-semibold",
				children: [
					"Cover ",
					state.cover.nps,
					"″"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "الوزن",
				value: digits(cover.totalG, "g"),
				unit: "جم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "التكلفة",
				value: cost.coverTotal == null ? "—" : digits(cost.coverTotal, "money"),
				unit: currency
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-4 text-lg font-semibold",
				children: [
					"الوصلة المعزولة ",
					state.insulated.nps,
					"″"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "سمك العزل",
				value: digits(insulated.insulationMm, "mm"),
				unit: "مم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "الوزن",
				value: digits(insulated.totalG, "g"),
				unit: "جم"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
				label: "تكلفة الخامات",
				value: cost.insTotal == null ? "—" : digits(cost.insTotal, "money"),
				unit: currency
			})
		]
	});
}
var npsOptions$2 = SCH40.map((row) => ({
	value: row.nps,
	label: `${row.nps}″`
}));
function TimePanel() {
	const state = useFlex();
	const digits = useDigits();
	const scenario = toScenario(state);
	const time = calcTime(scenario, toDrive(state), scenario.jointLengthM, scenario.pitchMm, state.time.headNps);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[22rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-ink",
				children: "زمن التصنيع"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "الطول والخطوة من الوصلة. لكل مقاس Head بقطر الـ ID بعد خصم الفريز."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {
						label: "طول الوصلة",
						value: `${state.joint.lengthM || "—"} م`,
						hint: "من حاسبة الاستهلاك"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Readout, {
						label: "خطوة اللفة",
						value: `${state.joint.pitchMm || "—"} مم`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "مقاس الـ Head",
						value: state.time.headNps,
						onChange: (headNps) => state.patchTime({ headNps }),
						options: npsOptions$2,
						hint: time.headIdMm == null ? "من جدول Sch 40" : `قطر الـ Head ${digits(time.headIdMm, "mm")} مم`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-sm font-medium text-ink",
						children: "طريقة دوران الـ Head"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-1 rounded-lg bg-paper-2 p-1",
						children: [["drive", "من الماتور"], ["direct", "إدخال مباشر"]].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": state.time.mode === value,
							className: `h-11 rounded-md text-sm font-medium ${state.time.mode === value ? "bg-card text-ink shadow-card" : "text-muted"}`,
							onClick: () => state.patchTime({ mode: value }),
							children: label
						}, value))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "سرعة الماتور المقننة",
						unit: "لفة/د",
						value: state.time.motorRpm,
						onChange: (motorRpm) => state.patchTime({ motorRpm })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "التردد المقنن",
							unit: "Hz",
							value: state.time.ratedHz,
							onChange: (ratedHz) => state.patchTime({ ratedHz })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "تردد الانفرتر",
							unit: "Hz",
							value: state.time.setHz,
							onChange: (setHz) => state.patchTime({ setHz })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "نسبة الجيربوكس",
							value: state.time.gearRatio,
							onChange: (gearRatio) => state.patchTime({ gearRatio })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "قطر الطنبورة",
							unit: "مم",
							value: state.time.pulleyMm,
							onChange: (pulleyMm) => state.patchTime({ pulleyMm }),
							hint: "الفعّال 92، وبالشفة 116"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "خصم فريز الـ Head",
						unit: "مم",
						value: state.time.grooveMm,
						onChange: (grooveMm) => state.patchTime({ grooveMm }),
						hint: "لو الـ 3 مم عمق نصف قطري اكتب 6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "دوران مباشر للـ Head",
						unit: "لفة/د",
						value: state.time.directRpm,
						onChange: (directRpm) => state.patchTime({ directRpm }),
						hint: "يُستخدم فقط مع الإدخال المباشر"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
						label: "زمن إضافي لكل وصلة",
						unit: "ث",
						value: state.time.extraSec,
						onChange: (extraSec) => state.patchTime({ extraSec }),
						hint: "تحميل أو ربط أو قطع. صفر = زمن الـ Head فقط"
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid content-start gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
					issues: time.issues,
					okText: "مدخلات الزمن سليمة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "زمن الوصلة",
							value: time.hms ?? "—",
							unit: ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "بالدقائق",
							value: digits(time.totalMin, "n"),
							unit: "د"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "إنتاج الساعة",
							value: digits(time.perHour, "n"),
							unit: "وصلة"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
							label: "سرعة التقدم",
							value: digits(time.advanceMPerMin, "n"),
							unit: "م/د"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "عدد اللفات",
						value: digits(time.turns, "n"),
						unit: "لفة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "سرعة الماتور الفعلية",
						value: digits(time.motorRpm, "n"),
						unit: "لفة/د",
						note: "المقننة × التردد المضبوط ÷ المقنن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "سرعة الطنبورة",
						value: digits(time.pulleyRpm, "n"),
						unit: "لفة/د"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "سرعة السير",
						value: digits(time.beltMPerMin, "n"),
						unit: "م/د"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "القطر الفعّال للـ Head",
						value: digits(time.headEffMm, "mm"),
						unit: "مم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "دوران الـ Head المحسوب",
						value: digits(time.headRpmCalc, "n"),
						unit: "لفة/د"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "الدوران المستخدم",
						value: digits(time.headRpm, "n"),
						unit: "لفة/د"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "زمن اللفة",
						value: digits(time.turnSec, "n"),
						unit: "ث"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
						label: "زمن اللف",
						value: digits(time.windSec, "n"),
						unit: "ث"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: "جدول التردد"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "نفس الماتور والطنبورة والفريز. عدّل الترددات كما تشاء."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[28rem] text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-start text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border-b border-line py-2 font-medium",
										children: "Hz"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border-b border-line py-2 font-medium",
										children: "لفة/د"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border-b border-line py-2 font-medium",
										children: "زمن ث"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border-b border-line py-2 font-medium",
										children: "وصلة/س"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: time.rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border-b border-line py-1.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "h-10 w-20 rounded-lg border border-line bg-card px-2 font-mono text-sm tabular-nums",
										dir: "ltr",
										inputMode: "decimal",
										value: state.time.freqRows[index] ?? "",
										onChange: (event) => state.setFreq(index, event.target.value)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border-b border-line py-1.5 font-mono tabular-nums",
									dir: "ltr",
									children: digits(row.headRpm, "n")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border-b border-line py-1.5 font-mono tabular-nums",
									dir: "ltr",
									children: digits(row.totalSec, "n")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "border-b border-line py-1.5 font-mono tabular-nums",
									dir: "ltr",
									children: digits(row.perHour, "n")
								})
							] }, index)) })]
						})
					})
				] })
			]
		})]
	});
}
var npsOptions$1 = SCH40.map((row) => ({
	value: row.nps,
	label: `${row.nps}″`
}));
function BomPanel() {
	const state = useFlex();
	const digits = useDigits();
	const bom = calcBom(toScenario(state), state.bom.product, state.bom.nps, num(state.bom.lengthM), num(state.bom.pieces));
	const currency = state.currency || "جنيه";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-ink",
					children: "قائمة المواد"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs text-muted",
					children: [
						"السلك والخطوة والخامات من الاستهلاك. المقاس والطول وعدد القطع من هنا.",
						" ",
						wireByKey(state.joint.wireKey)?.label,
						" · ",
						materialById(state.joint.material1)?.name,
						state.joint.layerType === "double" ? ` + ${materialById(state.joint.material2)?.name}` : "",
						" · ",
						"Cover ",
						materialById(state.cover.material)?.name
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 md:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "نوع المنتج",
							value: state.bom.product,
							onChange: (product) => state.patchBom({ product }),
							options: [
								{
									value: "joint",
									label: "وصلة"
								},
								{
									value: "cover",
									label: "Cover"
								},
								{
									value: "insulated",
									label: "وصلة معزولة"
								}
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "المقاس NPS",
							value: state.bom.nps,
							onChange: (nps) => state.patchBom({ nps }),
							options: npsOptions$1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "الطول",
							unit: "م",
							value: state.bom.lengthM,
							onChange: (lengthM) => state.patchBom({ lengthM })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "عدد القطع",
							value: state.bom.pieces,
							onChange: (pieces) => state.patchBom({ pieces })
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
				issues: bom.issues,
				okText: "مدخلات القائمة سليمة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
						label: "قطر المنتج",
						value: digits(bom.idMm, "mm"),
						unit: "مم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
						label: "قطر الغطاء",
						value: digits(bom.coverIdMm, "mm"),
						unit: "مم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
						label: "وزن القطعة",
						value: digits(bom.pieceWeightG, "g"),
						unit: "جم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
						label: "وزن الطلب",
						value: digits(bom.orderWeightKg, "n"),
						unit: "كجم"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold text-ink",
				children: "البنود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-start text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "البند"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "المواصفات"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "للقطعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "وزن القطعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "للطلب"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: bom.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: line.applies ? "" : "text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line py-2",
								children: line.item
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line py-2",
								children: line.applies ? line.spec : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line py-2 font-mono tabular-nums",
								dir: "ltr",
								children: line.applies ? `${digits(line.qty, line.unit === "جم" ? "g" : "len")} ${line.unit}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line py-2 font-mono tabular-nums",
								dir: "ltr",
								children: line.applies && line.weightG != null ? `${digits(line.weightG, "g")} جم` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "border-b border-line py-2 font-mono tabular-nums",
								dir: "ltr",
								children: line.applies ? `${digits(line.orderQty, line.unit === "جم" ? "g" : "len")} ${line.unit}` : "—"
							})
						]
					}, line.id)) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold text-ink",
					children: "الكرتونة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
					label: "الأبعاد الداخلية",
					value: bom.carton?.lengthMm == null ? "—" : `${digits(bom.carton.lengthMm, "mm")} × ${digits(bom.carton.widthMm, "mm")} × ${digits(bom.carton.heightMm, "mm")}`,
					unit: "مم",
					note: bom.carton?.auto ? `${productLabel(state.bom.product)} — قطر + 5 سم، والارتفاع ${state.bom.product === "insulated" ? "100 سم" : "40 سم"}` : "أبعاد مُدخلة يدويًا"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
					label: "عدد الكراتين للطلب",
					value: digits(bom.cartons, "n"),
					unit: "كرتونة",
					note: `${bom.carton?.piecesPerCarton ?? 1} قطعة في الكرتونة`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
					label: "تكلفة الكراتين",
					value: bom.carton?.missingPrice || bom.cartons == null || bom.carton?.unitPrice == null ? "بانتظار سعر المقاس" : digits(bom.cartons * bom.carton.unitPrice, "money"),
					unit: bom.carton?.missingPrice ? void 0 : currency
				})
			] })
		]
	});
}
var npsOptions = SCH40.map((row) => ({
	value: row.nps,
	label: `${row.nps}″`
}));
var KIND_LABEL = {
	receipt: "استلام",
	return: "مرتجع",
	issue: "صرف"
};
function StockPanel() {
	const state = useFlex();
	const digits = useDigits();
	const scenario = toScenario(state);
	const drive = toDrive(state);
	const lengthM = num(state.plan.lengthM);
	const pieces = num(state.plan.batch);
	const bom = calcBom(scenario, state.plan.product, state.plan.nps, lengthM, pieces != null && pieces > 0 ? pieces : 1);
	const needs = bomNeeds(scenario, bom, state.plan.product);
	const seconds = makeSecondsFor(scenario, drive, state.plan.product, state.plan.nps, lengthM);
	const manualDay = num(state.plan.piecesPerDay);
	const hoursPerDay = num(state.plan.hoursPerDay);
	const secondsForRate = state.plan.rateMode === "manual" && manualDay != null && manualDay > 0 && hoursPerDay != null && hoursPerDay > 0 ? hoursPerDay * 3600 / manualDay : seconds;
	const coverage = calcCoverage(needs, Object.fromEntries(Object.entries(state.stock).map(([id, row]) => [id, {
		qty: num(row.qty),
		unit: row.unit
	}])), secondsForRate, hoursPerDay, pieces, scenario);
	const catalog = stockCatalog();
	const [itemId, setItemId] = (0, import_react.useState)(catalog[0]?.id ?? "glue");
	const [kind, setKind] = (0, import_react.useState)("receipt");
	const [qty, setQty] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [posted, setPosted] = (0, import_react.useState)(null);
	const activeCarton = needs.find((need) => need.itemId.startsWith("carton:"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-ink",
				children: "رصيد الخامات"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "اكتب رصيد المخزن. الاستلام والمرتجع يزودان الرصيد، والصرف ينقصه. التنبيه يحسب كم تكفي الخامات لو اتصنعت الوصلة اللي تحت."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: "ما الذي هيتصنع؟"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
								label: "المنتج",
								value: state.plan.product,
								onChange: (product) => state.patchPlan({ product }),
								options: [
									{
										value: "joint",
										label: "وصلة"
									},
									{
										value: "cover",
										label: "Cover"
									},
									{
										value: "insulated",
										label: "وصلة معزولة"
									}
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
								label: "المقاس",
								value: state.plan.nps,
								onChange: (nps) => state.patchPlan({ nps }),
								options: npsOptions
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: "طول القطعة",
								unit: "م",
								value: state.plan.lengthM,
								onChange: (lengthM) => state.patchPlan({ lengthM })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: "كمية طلب للمقارنة",
								value: state.plan.batch,
								onChange: (batch) => state.patchPlan({ batch }),
								hint: "فاضي = من غير مقارنة طلب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: "ساعات التشغيل في اليوم",
								value: state.plan.hoursPerDay,
								onChange: (hoursPerDay) => state.patchPlan({ hoursPerDay })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-sm font-medium text-ink",
								children: "معدل الإنتاج"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-1 rounded-lg bg-paper-2 p-1",
								children: [["machine", "من الماكينة"], ["manual", "رقم يدوي"]].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": state.plan.rateMode === value,
									className: `h-11 rounded-md text-sm font-medium ${state.plan.rateMode === value ? "bg-card text-ink shadow-card" : "text-muted"}`,
									onClick: () => state.patchPlan({ rateMode: value }),
									children: label
								}, value))
							})] }),
							state.plan.rateMode === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: "قطع في اليوم",
								value: state.plan.piecesPerDay,
								onChange: (piecesPerDay) => state.patchPlan({ piecesPerDay })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted sm:col-span-2",
								children: [
									"زمن القطعة من بيانات الماكينة في «زمن التصنيع»",
									seconds == null ? " — الزمن غير مكتمل." : ` — ${digits((seconds ?? 0) / 60, "n")} دقيقة للقطعة.`,
									state.plan.product === "insulated" ? " المعزولة = لف الوصلة + لف الغطاء." : ""
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 text-sm font-medium text-copper",
						onClick: () => state.patchPlan({
							nps: state.plan.product === "cover" ? state.cover.nps : state.plan.product === "insulated" ? state.insulated.nps : state.joint.nps,
							lengthM: state.plan.product === "cover" ? state.cover.lengthM : state.plan.product === "insulated" ? state.insulated.lengthM : state.joint.lengthM
						}),
						children: "انسخ المقاس والطول من الحاسبة"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-2xl p-4 shadow-card ${coverage.bottleneck && (coverage.bottleneck.pieces ?? 0) <= 0 ? "bg-warn-bg text-warn" : "bg-steel text-steel-ink"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm opacity-80",
							children: "تنبيه التغطية"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base font-semibold leading-7",
							children: coverage.headline
						}),
						coverage.piecesPerHour != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 font-mono text-sm tabular-nums",
							dir: "ltr",
							children: [digits(coverage.piecesPerHour, "n"), " قطعة/ساعة"]
						}) : null,
						coverage.bottleneck?.days != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm opacity-80",
							children: [
								formatDays(coverage.bottleneck.days),
								" عند ",
								state.plan.hoursPerDay || "—",
								" ساعات."
							]
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBanner, {
				issues: bom.issues.filter((issue) => issue.tone === "bad"),
				okText: "مواصفات القطعة صالحة لحساب الاستهلاك"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
				className: "text-sm font-semibold text-ink",
				children: [
					"كفاية كل خامة لـ ",
					productLabel(state.plan.product),
					" ",
					state.plan.nps,
					"″"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[42rem] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-start text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "الخامة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "للقطعة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "الرصيد"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "قطع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "المدة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "border-b border-line py-2 font-medium",
								children: "الطلب"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: coverage.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "border-b border-line py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: row.label }), row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-warn",
								children: row.note
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "border-b border-line py-2 font-mono tabular-nums",
							dir: "ltr",
							children: [
								digits(row.perPiece, "n"),
								" ",
								unitOf(row.unit)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line py-2 font-mono tabular-nums",
							dir: "ltr",
							children: digits(row.stock, "n")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line py-2 font-mono tabular-nums",
							dir: "ltr",
							children: digits(row.pieces, "n")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line py-2",
							children: row.hours == null ? "—" : formatHours(row.hours)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-b border-line py-2",
							children: row.batchOk == null ? "—" : row.batchOk ? "يكفي" : "لا يكفي"
						})
					] }, row.itemId)) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold text-ink",
					children: "أرصدة المخزن"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid gap-3",
					children: [catalog.map((item) => {
						const row = state.stock[item.id] ?? {
							qty: "",
							unit: item.defaultUnit
						};
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 border-b border-line py-3 sm:grid-cols-[minmax(0,1fr)_8rem_8rem] sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-ink",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: item.hint
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `${fieldClass} font-mono tabular-nums`,
									dir: "ltr",
									inputMode: "decimal",
									placeholder: "0",
									value: row.qty,
									onChange: (event) => state.setStock(item.id, { qty: event.target.value })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: fieldClass,
									value: row.unit,
									onChange: (event) => state.setStock(item.id, { unit: event.target.value }),
									children: item.units.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: unit,
										children: unitLabel(unit)
									}, unit))
								})
							]
						}, item.id);
					}), activeCarton ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 py-3 sm:grid-cols-[minmax(0,1fr)_8rem] sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-ink",
							children: activeCarton.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "كرتونة المقاس المختار في الخطة"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} font-mono tabular-nums`,
							dir: "ltr",
							inputMode: "decimal",
							placeholder: "0",
							value: state.stock[activeCarton.itemId]?.qty ?? "",
							onChange: (event) => state.setStock(activeCarton.itemId, {
								qty: event.target.value,
								unit: "carton"
							})
						})]
					}) : null]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold text-ink",
						children: "حركة مخزن"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 grid gap-3",
						onSubmit: (event) => {
							event.preventDefault();
							const ok = state.postMovement(itemId, kind, qty, note);
							setPosted(ok ? "اتسجلت الحركة على الرصيد." : "اكتب كمية أكبر من صفر.");
							if (ok) {
								setQty("");
								setNote("");
							}
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-sm font-medium text-ink",
									children: "الخامة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: fieldClass,
									value: itemId,
									onChange: (event) => setItemId(event.target.value),
									children: [catalog.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: item.id,
										children: item.label
									}, item.id)), activeCarton ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: activeCarton.itemId,
										children: activeCarton.label
									}) : null]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-3 gap-1 rounded-lg bg-paper-2 p-1",
								children: [
									"receipt",
									"return",
									"issue"
								].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": kind === value,
									className: `h-11 rounded-md text-sm font-medium ${kind === value ? "bg-card text-ink shadow-card" : "text-muted"}`,
									onClick: () => setKind(value),
									children: KIND_LABEL[value]
								}, value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
								label: "الكمية",
								value: qty,
								onChange: setQty,
								hint: "بنفس وحدة رصيد الخامة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-1 block text-sm font-medium text-ink",
									children: "ملاحظة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: note,
									placeholder: "رقم إذن أو سبب المرتجع",
									onChange: (event) => setNote(event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "submit",
								className: "h-11 rounded-lg bg-copper text-sm font-semibold text-copper-ink",
								children: ["تسجيل ", KIND_LABEL[kind]]
							}),
							posted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: posted
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 grid gap-2",
						children: [state.movements.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm text-muted",
							children: "لا توجد حركات بعد."
						}) : null, state.movements.slice(0, 8).map((move) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-paper px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium text-ink",
								children: [
									KIND_LABEL[move.kind],
									" · ",
									digits(num(move.qty), "n")
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [catalog.find((item) => item.id === move.itemId)?.label ?? move.itemId, move.note ? ` · ${move.note}` : ""]
							})]
						}, move.id))]
					})
				] })]
			})
		]
	});
}
function unitOf(unit) {
	if (unit === "m") return "م";
	if (unit === "g") return "جم";
	if (unit === "m2") return "م²";
	return "كرتونة";
}
var SECTIONS = [
	{
		id: "joint",
		label: "الوصلة",
		hint: "سلك وخامة وغراء",
		icon: Spline
	},
	{
		id: "cover",
		label: "الغطاء",
		hint: "لف بدون سلك",
		icon: Shield
	},
	{
		id: "insulated",
		label: "العزل",
		hint: "صوف وغطاء",
		icon: Layers
	},
	{
		id: "time",
		label: "زمن التصنيع",
		hint: "ماتور وانفرتر",
		icon: Timer
	},
	{
		id: "bom",
		label: "قائمة المواد",
		hint: "قطعة وطلب وكرتونة",
		icon: ClipboardList
	},
	{
		id: "cost",
		label: "التكاليف",
		hint: "وصلة أو غطاء أو عزل",
		icon: Coins
	},
	{
		id: "stock",
		label: "رصيد الخامات",
		hint: "مخزن ومرتجع وتغطية",
		icon: Warehouse
	},
	{
		id: "tables",
		label: "الجداول",
		hint: "Sch 40 وأسعار الكراتين",
		icon: Table2
	}
];
function isStandalone() {
	if (typeof window === "undefined") return false;
	const nav = window.navigator;
	return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}
function Workspace() {
	const section = useFlex((state) => state.section);
	const setSection = useFlex((state) => state.setSection);
	const installDismissed = useFlex((state) => state.installDismissed);
	const dismissInstall = useFlex((state) => state.dismissInstall);
	const precision = useFlex((state) => state.precision);
	const setPrecision = useFlex((state) => state.setPrecision);
	const resetRecipe = useFlex((state) => state.resetRecipe);
	const pack = usePack();
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [installOpen, setInstallOpen] = (0, import_react.useState)(false);
	const [quotesOpen, setQuotesOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [shareText, setShareText] = (0, import_react.useState)(null);
	const [standalone, setStandalone] = (0, import_react.useState)(false);
	const [deferred, setDeferred] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		useFlex.persist.rehydrate();
		setStandalone(isStandalone());
		const onPrompt = (event) => {
			event.preventDefault();
			setDeferred(event);
		};
		const onInstalled = () => {
			setDeferred(null);
			setStandalone(true);
		};
		window.addEventListener("beforeinstallprompt", onPrompt);
		window.addEventListener("appinstalled", onInstalled);
		return () => {
			window.removeEventListener("beforeinstallprompt", onPrompt);
			window.removeEventListener("appinstalled", onInstalled);
		};
	}, []);
	const current = SECTIONS.find((item) => item.id === section);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "no-print bg-steel text-steel-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/favicon.svg",
							alt: "",
							className: "size-11 rounded-lg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-steel-ink/70",
								children: "خط الفليكسيبل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-lg font-semibold leading-tight",
								children: current?.label ?? "قوائم الخط"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-11 items-center gap-2 rounded-lg bg-copper px-3 text-sm font-semibold text-copper-ink",
							onClick: () => setInstallOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
								className: "size-4",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "تثبيت"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex h-11 items-center rounded-lg bg-steel-ink/10 px-3 text-sm font-medium text-steel-ink",
									"aria-expanded": menu,
									onClick: () => setMenu((open) => !open),
									children: "المزيد"
								}),
								menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "fixed inset-0 z-30 cursor-default",
									"aria-label": "إغلاق القائمة",
									onClick: () => setMenu(false)
								}) : null,
								menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute end-0 z-40 mt-2 w-56 rounded-xl bg-card p-1 text-ink shadow-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
											icon: Printer,
											label: "طباعة البيان",
											onClick: () => {
												setMenu(false);
												window.print();
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
											icon: Copy,
											label: copied ? "تم النسخ" : "نسخ الملخص",
											onClick: () => {
												setMenu(false);
												const text = summaryText(pack, pack.state.currency || "جنيه");
												navigator.clipboard.writeText(text).then(() => {
													setCopied(true);
													window.setTimeout(() => setCopied(false), 1600);
												}, () => setShareText(text));
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
											icon: Bookmark,
											label: "الحسبات المحفوظة",
											onClick: () => {
												setMenu(false);
												setQuotesOpen(true);
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
											icon: RotateCcw,
											label: "استعادة مثال الإكسيل",
											onClick: () => {
												setMenu(false);
												resetRecipe();
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-11 w-full items-center rounded-lg px-3 text-start text-sm",
											onClick: () => setPrecision(!precision),
											children: precision ? "إخفاء الأرقام المفصّلة" : "أرقام مفصّلة مثل الإكسيل"
										})
									]
								}) : null
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-2 px-4 py-2",
					children: [section ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex h-11 shrink-0 items-center gap-1 rounded-lg px-2 text-sm font-medium text-ink",
						onClick: () => setSection(null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4",
							"aria-hidden": "true"
						}), "القوائم"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "inline-flex h-11 shrink-0 items-center gap-1 rounded-lg px-2 text-sm font-medium text-ink",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4",
							"aria-hidden": "true"
						}), "الخطوط"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex gap-1 overflow-x-auto",
						"aria-label": "أقسام الخط",
						children: SECTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `inline-flex h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-sm font-medium ${section === item.id ? "bg-card text-copper shadow-card" : "text-muted"}`,
							onClick: () => setSection(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
								className: "size-4",
								"aria-hidden": "true"
							}), item.label]
						}, item.id))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-6xl gap-4 px-4 py-4 pb-8",
				children: [
					!installDismissed && !standalone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "no-print flex items-center gap-3 rounded-2xl bg-steel px-3 py-3 text-steel-ink shadow-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, {
								className: "size-5 shrink-0",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 flex-1 text-sm",
								children: "يثبَّت على أندرويد من Chrome ويُفتح من الشاشة الرئيسية. ملف APK غير متاح من هنا."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 shrink-0 rounded-lg bg-copper px-3 text-sm font-semibold text-copper-ink",
								onClick: () => setInstallOpen(true),
								children: "طريقة التثبيت"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-11 items-center justify-center",
								"aria-label": "إخفاء",
								onClick: dismissInstall,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})
						]
					}) : null,
					section == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionMenu, { onOpen: setSection }) : null,
					section === "joint" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JointPanel, {}) : null,
					section === "cover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverPanel, {}) : null,
					section === "insulated" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsulatedPanel, {}) : null,
					section === "time" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimePanel, {}) : null,
					section === "bom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BomPanel, {}) : null,
					section === "cost" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostPanel, {}) : null,
					section === "stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockPanel, {}) : null,
					section === "tables" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TablesPanel, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintReport, {}),
			installOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstallDialog, {
				standalone,
				canPrompt: deferred != null,
				onClose: () => setInstallOpen(false),
				onInstall: () => {
					deferred?.prompt().then(() => setDeferred(null));
				}
			}) : null,
			quotesOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotesDialog, { onClose: () => setQuotesOpen(false) }) : null,
			shareText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
				title: "انسخ الملخص",
				onClose: () => setShareText(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "h-48 w-full rounded-lg border border-line bg-paper p-3 font-mono text-xs text-ink",
					dir: "ltr",
					readOnly: true,
					value: shareText
				})
			}) : null
		]
	});
}
function SectionMenu({ onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sm:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "اختَر القائمة. الخطوط الأخرى هتتضاف جنب خط الفليكسيبل من غير ما تختلط الحسابات."
				})
			}),
			SECTIONS.map((item) => {
				const Icon = item.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-3 rounded-2xl bg-card p-4 text-start shadow-card",
					onClick: () => onOpen(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex size-11 items-center justify-center rounded-xl bg-paper text-copper",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base font-semibold text-ink",
						children: item.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: item.hint
					})] })]
				}, item.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-xs text-muted sm:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boxes, {
					className: "size-4",
					"aria-hidden": "true"
				}), "المواصفات محفوظة على هذا الجهاز."]
			})
		]
	});
}
function MenuButton({ icon: Icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex h-11 w-full items-center gap-2 rounded-lg px-3 text-start text-sm",
		onClick,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4 text-muted",
			"aria-hidden": "true"
		}), label]
	});
}
function InstallDialog({ standalone, canPrompt, onClose, onInstall }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
		title: "التثبيت على الموبايل",
		onClose,
		children: standalone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-ink",
			children: "البرنامج مفتوح كتطبيق من الشاشة الرئيسية."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink",
				children: "لا يُولَّد ملف APK من هنا. بعد النشر افتح الرابط في Chrome على أندرويد ثم ثبّت التطبيق، والأرقام تفضل على الجهاز."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-3 list-decimal space-y-2 ps-5 text-sm text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "انشر البرنامج وافتح رابطه في Chrome على الموبايل." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "من قائمة Chrome اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "الأيقونة «خط الفليكسيبل» تظهر على الشاشة الرئيسية." })
				]
			}),
			canPrompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 h-11 w-full rounded-lg bg-copper text-sm font-semibold text-copper-ink",
				onClick: onInstall,
				children: "تثبيت التطبيق"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl bg-paper px-3 py-2 text-xs text-muted",
				children: "زر التثبيت المباشر يظهر عندما يسمح المتصفح."
			})
		] })
	});
}
function QuotesDialog({ onClose }) {
	const quotes = useFlex((state) => state.quotes);
	const saveQuote = useFlex((state) => state.saveQuote);
	const loadQuote = useFlex((state) => state.loadQuote);
	const deleteQuote = useFlex((state) => state.deleteQuote);
	const [name, setName] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		title: "الحسبات المحفوظة",
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "تتحفظ على هذا الجهاز فقط، من غير رصيد المخزن."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					saveQuote(name);
					setName("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-card px-3 text-sm text-ink outline-none focus:border-copper",
					placeholder: "اسم الحسبة",
					value: name,
					onChange: (event) => setName(event.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 shrink-0 rounded-lg bg-copper px-3 text-sm font-semibold text-copper-ink",
					children: "حفظ الحالية"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 grid gap-2",
				children: [quotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "لا توجد حسبات محفوظة بعد."
				}) : null, quotes.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-xl bg-paper px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium text-ink",
								children: quote.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: new Intl.DateTimeFormat("ar-EG", {
									dateStyle: "medium",
									timeStyle: "short",
									numberingSystem: "latn"
								}).format(new Date(quote.savedAt))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-lg bg-card px-3 text-sm font-medium text-ink shadow-card",
							onClick: () => {
								loadQuote(quote.id);
								onClose();
							},
							children: "فتح"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 px-2 text-sm text-warn",
							onClick: () => deleteQuote(quote.id),
							children: "حذف"
						})
					]
				}, quote.id))]
			})
		]
	});
}
function Overlay({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "no-print fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-3 md:items-center",
		role: "presentation",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-card p-4 shadow-card",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-ink",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-lg",
					"aria-label": "إغلاق",
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), children]
		})
	});
}
function FlexLine() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workspace, {});
}
//#endregion
export { FlexLine as component };
