import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as ArrowLeft, m as Factory } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DDeIe9au.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen max-w-3xl flex-col px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-copper",
				children: "غرفة الخطوط"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-semibold text-ink",
				children: "خطوط الإنتاج"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm text-muted",
				children: "ادخل الخط المطلوب. خط الفليكسيبل هو الموجود الآن، والخطوط التالية تتضاف من نفس الباب من غير ما تختلط حساباتها."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/flex",
				className: "mt-8 flex items-center gap-4 rounded-2xl bg-steel p-5 text-steel-ink shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-flex size-14 items-center justify-center rounded-xl bg-copper text-copper-ink",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Factory, {
							className: "size-7",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xl font-semibold",
							children: "خط الفليكسيبل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-sm text-steel-ink/75",
							children: "استهلاك · زمن تصنيع · قائمة مواد · تكاليف · رصيد خامات"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {
						className: "size-5 shrink-0",
						"aria-hidden": "true"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs text-muted",
				children: "لا توجد خطوط أخرى مفعّلة بعد."
			})
		]
	});
}
//#endregion
export { Home as component };
