//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-9uSN-RvR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/flex"],
		preloads: ["/assets/index-BeHfhOW_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BeHfhOW_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DbAYEPb3.js"]
	},
	"/flex": {
		filePath: "/workspace/src/routes/flex.tsx",
		children: void 0,
		preloads: ["/assets/flex-DsDbQGyR.js"]
	}
} });
//#endregion
export { tsrStartManifest };
